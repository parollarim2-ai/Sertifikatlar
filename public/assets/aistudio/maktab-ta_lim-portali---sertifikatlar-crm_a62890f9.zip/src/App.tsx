import React, { useState } from 'react';
import { DatabaseProvider, useDatabase } from './context/DatabaseContext';
import { ToastContainer } from './components/Toast';
import { Header } from './components/Header';
import { ClassTabs } from './components/ClassTabs';
import { StudentTable } from './components/StudentTable';
import { EditStudentModal } from './components/EditStudentModal';
import { SmartImportModal } from './components/SmartImportModal';
import { ClassManageModal } from './components/ClassManageModal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { BackupModal } from './components/BackupModal';
import { FinanceMatrix } from './components/FinanceMatrix';
import { TeacherCertificates } from './components/TeacherCertificates';
import { Student, ClassGroup } from './types';
import { Shield, Sparkles, CheckCircle2, Lock } from 'lucide-react';

const MainContent: React.FC = () => {
  const { data, isLoading } = useDatabase();

  const [currentTab, setCurrentTab] = useState<'students' | 'teachers' | 'finance'>('students');
  const [selectedClassId, setSelectedClassId] = useState<string>(() => {
    return data.classes[0]?.id || 'cls-5a';
  });

  // Modal open states
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [isSmartImportOpen, setIsSmartImportOpen] = useState(false);
  const [isClassModalOpen, setIsClassModalOpen] = useState(false);
  const [classToEdit, setClassToEdit] = useState<ClassGroup | null>(null);
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [studentToEdit, setStudentToEdit] = useState<Student | null>(null);

  // Sync selectedClassId if current class was deleted
  const currentClassExists = data.classes.some((c) => c.id === selectedClassId);
  const effectiveClassId = currentClassExists ? selectedClassId : data.classes[0]?.id || '';

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 animate-spin flex items-center justify-center text-white mx-auto">
            <Sparkles className="w-6 h-6" />
          </div>
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
            Maktab Ta'lim Portali yuklanmoqda...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-slate-100/60 to-blue-50/40 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 text-slate-800 dark:text-slate-100 font-sans selection:bg-blue-500 selection:text-white">
      {/* Toast Notification Container */}
      <ToastContainer />

      {/* Main Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenAdminLogin={() => setIsAdminLoginOpen(true)}
        onOpenBackupModal={() => setIsBackupModalOpen(true)}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {currentTab === 'students' && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <ClassTabs
              selectedClassId={effectiveClassId}
              onSelectClass={(id) => setSelectedClassId(id)}
              onOpenAddClass={() => {
                setClassToEdit(null);
                setIsClassModalOpen(true);
              }}
              onOpenEditClass={(cls) => {
                setClassToEdit(cls);
                setIsClassModalOpen(true);
              }}
            />

            {effectiveClassId && (
              <StudentTable
                classId={effectiveClassId}
                onOpenAddStudent={() => {
                  setStudentToEdit(null);
                  setIsStudentModalOpen(true);
                }}
                onOpenSmartImport={() => setIsSmartImportOpen(true)}
                onEditStudent={(student) => {
                  setStudentToEdit(student);
                  setIsStudentModalOpen(true);
                }}
              />
            )}
          </div>
        )}

        {currentTab === 'teachers' && (
          <div className="animate-in fade-in duration-200">
            <TeacherCertificates />
          </div>
        )}

        {currentTab === 'finance' && (
          <div className="animate-in fade-in duration-200">
            <FinanceMatrix />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/80 dark:border-slate-800/80 py-5 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>
              Zero-Data-Loss Himoyasi: Baza doimiy ravishda LocalStorage va server zaxirasida saqlanadi.
            </span>
          </div>

          <div className="flex items-center gap-4">
            <span>Maktab Ta'lim Portali v2.6 Pro</span>
            <span className="h-3 w-px bg-slate-300 dark:bg-slate-700" />
            <button
              onClick={() => setIsAdminLoginOpen(true)}
              className="text-slate-600 dark:text-slate-400 hover:text-blue-600 transition-colors flex items-center gap-1"
            >
              <Lock className="w-3 h-3" />
              <span>Admin Rejimi</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Global Modals */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
      />

      <BackupModal
        isOpen={isBackupModalOpen}
        onClose={() => setIsBackupModalOpen(false)}
      />

      <SmartImportModal
        isOpen={isSmartImportOpen}
        initialClassId={effectiveClassId}
        onClose={() => setIsSmartImportOpen(false)}
      />

      <ClassManageModal
        isOpen={isClassModalOpen}
        classToEdit={classToEdit}
        onClose={() => {
          setIsClassModalOpen(false);
          setClassToEdit(null);
        }}
      />

      <EditStudentModal
        isOpen={isStudentModalOpen}
        student={studentToEdit}
        defaultClassId={effectiveClassId}
        onClose={() => {
          setIsStudentModalOpen(false);
          setStudentToEdit(null);
        }}
      />
    </div>
  );
};

export default function App() {
  return (
    <DatabaseProvider>
      <MainContent />
    </DatabaseProvider>
  );
}
