export type StudentStatus = 'pending' | 'certified' | 'error';
export type PaymentStatus = 'paid' | 'partial' | 'unpaid';

export interface Student {
  id: string;
  classId: string;
  fullName: string;
  passport: string;
  birthDate: string;
  status: StudentStatus;
  certificateUrl?: string;
  certifiedAt?: string;
  paidAmount: number;
  errorReason?: string;
  errorScreenshot?: string;
}

export interface ClassGroup {
  id: string;
  name: string;
  teacherName: string;
  teacherPhone: string;
  certificatePrice: number;
  paidAmount: number;
}

export interface TeacherCertificate {
  id: string;
  fullName: string;
  subject: string;
  passport: string;
  birthDate: string;
  emailOrPhone: string;
  certificateUrl?: string;
  certifiedAt?: string;
  status: StudentStatus;
  price: number;
  paidAmount: number;
  notes?: string;
}

export interface AppSettings {
  defaultCertificatePrice: number;
  schoolName: string;
  lastUpdated: string;
}

export interface DatabaseState {
  classes: ClassGroup[];
  students: Student[];
  teachers: TeacherCertificate[];
  settings: AppSettings;
}
