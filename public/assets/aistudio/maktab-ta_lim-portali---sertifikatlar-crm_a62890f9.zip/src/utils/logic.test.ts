import test from 'node:test';
import assert from 'node:assert/strict';
import {
  extractPassport7Digits,
  formatFullPassport,
  parseSmartStudentText,
  calculateFinanceMetrics,
  generateTelegramReport,
  isSafeToOverwrite,
  DatabaseState
} from './logic';

test('extractPassport7Digits extracts last 7 numeric digits properly', () => {
  assert.equal(extractPassport7Digits('AA1234567'), '1234567');
  assert.equal(extractPassport7Digits('AB 9876543'), '9876543');
  assert.equal(extractPassport7Digits('I-TO 0123456'), '0123456');
  assert.equal(extractPassport7Digits('1234567'), '1234567');
  assert.equal(extractPassport7Digits(''), '');
});

test('formatFullPassport standardizes formatting', () => {
  assert.equal(formatFullPassport('  aa 1234567 '), 'AA1234567');
  assert.equal(formatFullPassport('ab  9998877'), 'AB9998877');
});

test('parseSmartStudentText parses pipe-delimited and tab-delimited text', () => {
  const sample = `
1. Karimov Sanjarbek | AA 7766554 | 15.03.2009
2. Saidova Madina | AB1122334 | 2008-11-20
3. Xolmatov Dilshod	AC9988776	05/09/2010
`;
  const result = parseSmartStudentText(sample, 'class-1');
  assert.equal(result.students.length, 3);
  assert.equal(result.students[0].fullName, 'Karimov Sanjarbek');
  assert.equal(result.students[0].passport, 'AA7766554');
  assert.equal(result.students[0].birthDate, '15.03.2009');
  assert.equal(result.students[1].fullName, 'Saidova Madina');
  assert.equal(result.students[2].passport, 'AC9988776');
});

test('calculateFinanceMetrics calculates debt and statuses accurately', () => {
  const unpaid = calculateFinanceMetrics({
    studentCount: 20,
    pricePerStudent: 10000,
    paidAmount: 0,
  });
  assert.equal(unpaid.totalDue, 200000);
  assert.equal(unpaid.debt, 200000);
  assert.equal(unpaid.status, 'unpaid');

  const partial = calculateFinanceMetrics({
    studentCount: 20,
    pricePerStudent: 10000,
    paidAmount: 120000,
  });
  assert.equal(partial.totalDue, 200000);
  assert.equal(partial.debt, 80000);
  assert.equal(partial.status, 'partial');

  const full = calculateFinanceMetrics({
    studentCount: 20,
    pricePerStudent: 10000,
    paidAmount: 200000,
  });
  assert.equal(full.totalDue, 200000);
  assert.equal(full.debt, 0);
  assert.equal(full.status, 'paid');
});

test('generateTelegramReport creates formatted emoji report', () => {
  const report = generateTelegramReport({
    scopeName: "10-A sinf",
    totalStudents: 25,
    certifiedCount: 20,
    pendingCount: 5,
    errorCount: 0,
    totalPrice: 250000,
    paidAmount: 200000,
    debtAmount: 50000,
  });
  assert.match(report, /🎓 10-A SINF SERTIFIKAT NATIJALARI/);
  assert.match(report, /Jami o'quvchilar: 25 nafar/);
  assert.match(report, /Sertifikat olganlar: 20 nafar/);
  assert.match(report, /Qarz: 50/);
});

test('isSafeToOverwrite blocks accidental wipe of full database with empty database', () => {
  const existing: DatabaseState = {
    classes: [{ id: '1', name: '5-A', teacherName: 'Olimov', teacherPhone: '', certificatePrice: 10000, paidAmount: 0 }],
    students: [{ id: 's1', classId: '1', fullName: 'Ali Valiyev', passport: 'AA1112223', birthDate: '01.01.2010', status: 'pending', paidAmount: 0 }],
    teachers: [],
    settings: { defaultCertificatePrice: 10000, schoolName: '21-Maktab', lastUpdated: '' }
  };

  const empty: DatabaseState = {
    classes: [],
    students: [],
    teachers: [],
    settings: { defaultCertificatePrice: 10000, schoolName: '21-Maktab', lastUpdated: '' }
  };

  const safeCheck = isSafeToOverwrite(existing, empty, false);
  assert.equal(safeCheck.safe, false);

  const forcedCheck = isSafeToOverwrite(existing, empty, true);
  assert.equal(forcedCheck.safe, true);
});
