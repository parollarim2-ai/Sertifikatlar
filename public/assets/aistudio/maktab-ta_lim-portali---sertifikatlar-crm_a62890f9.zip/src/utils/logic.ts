export interface Student {
  id: string;
  classId: string;
  fullName: string;
  passport: string;
  birthDate: string;
  status: 'pending' | 'certified' | 'error';
  certificateUrl?: string;
  certifiedAt?: string; // ISO string with seconds
  paidAmount: number;
  errorReason?: string;
  errorScreenshot?: string;
}

export interface ClassGroup {
  id: string;
  name: string; // "5-A", "6-D", etc.
  teacherName: string;
  teacherPhone: string;
  certificatePrice: number; // default 10000
  paidAmount: number;
}

export interface TeacherCertificate {
  id: string;
  fullName: string;
  subject: string;
  passport: string;
  birthDate: string;
  emailOrPhone: string;
  certificateUrl?: string;
  certifiedAt?: string;
  status: 'pending' | 'certified' | 'error';
  price: number; // default 10000
  paidAmount: number;
  notes?: string;
}

export interface DatabaseState {
  classes: ClassGroup[];
  students: Student[];
  teachers: TeacherCertificate[];
  settings: {
    defaultCertificatePrice: number;
    schoolName: string;
    lastUpdated: string;
  };
}

/**
 * Extracts only 7-digit numeric part of passport/birth cert for rapid entry
 */
export function extractPassport7Digits(passport: string): string {
  if (!passport) return '';
  const digits = passport.replace(/\D/g, '');
  if (digits.length >= 7) {
    return digits.slice(-7);
  }
  return digits;
}

/**
 * Cleans and standardizes full passport string (e.g. AA 1234567 -> AA1234567)
 */
export function formatFullPassport(passport: string): string {
  if (!passport) return '';
  return passport.trim().toUpperCase().replace(/\s+/g, '');
}

/**
 * Parses smart free-form text from Telegram, Word, Excel, or tables
 * Supported formats:
 * - Ali Valiyev | AA1234567 | 12.05.2010
 * - 1. Qodirova Malika AA7654321 2009-04-15
 * - Umarov Bekzod	AB 3344556	01/01/2008
 */
export function parseSmartStudentText(rawText: string, classId: string, defaultPrice: number = 10000): {
  students: Omit<Student, 'id'>[];
  errors: { line: string; reason: string }[];
} {
  const lines = rawText.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const students: Omit<Student, 'id'>[] = [];
  const errors: { line: string; reason: string }[] = [];

  for (const line of lines) {
    // Strip leading numbering like "1.", "1)", "1 - "
    const cleanedLine = line.replace(/^\d+[\.\)\-\s]+/, '').trim();
    if (!cleanedLine) continue;

    // Try splitting by common delimiters: tab, pipe, semicolon, comma
    let parts: string[] = [];
    if (cleanedLine.includes('\t')) {
      parts = cleanedLine.split('\t');
    } else if (cleanedLine.includes('|')) {
      parts = cleanedLine.split('|');
    } else if (cleanedLine.includes(';')) {
      parts = cleanedLine.split(';');
    } else if (cleanedLine.includes(',') && !cleanedLine.includes('  ')) {
      parts = cleanedLine.split(',');
    } else {
      // Split by 2 or more spaces or regex
      parts = cleanedLine.split(/\s{2,}/);
    }

    parts = parts.map(p => p.trim()).filter(Boolean);

    let fullName = '';
    let passport = '';
    let birthDate = '';

    if (parts.length >= 3) {
      fullName = parts[0];
      passport = formatFullPassport(parts[1]);
      birthDate = normalizeDate(parts[2]);
    } else if (parts.length === 2) {
      fullName = parts[0];
      // check if second part has both passport and date
      const dateMatch = parts[1].match(/\b(\d{1,4}[.\/-]\d{1,2}[.\/-]\d{1,4})\b/);
      if (dateMatch) {
        birthDate = normalizeDate(dateMatch[0]);
        passport = formatFullPassport(parts[1].replace(dateMatch[0], '').trim());
      } else {
        passport = formatFullPassport(parts[1]);
      }
    } else {
      // Single continuous line: use regex to search for passport and date
      const text = cleanedLine;
      // Date regex: e.g. 12.04.2008 or 2008-04-12
      const dateMatch = text.match(/\b(\d{1,4}[.\/-]\d{1,2}[.\/-]\d{1,4})\b/);
      if (dateMatch) {
        birthDate = normalizeDate(dateMatch[0]);
      }

      // Passport regex: e.g. AA 1234567, AA1234567, I-TO 1234567, or 7 digits
      const passMatch = text.match(/\b([A-Z]{2}\s*\d{7}|[I|V|X]+-[A-Z]{2}\s*\d{6,7}|\d{7})\b/i);
      if (passMatch) {
        passport = formatFullPassport(passMatch[0]);
      }

      // Remaining part is considered fullName
      let rem = text;
      if (dateMatch) rem = rem.replace(dateMatch[0], ' ');
      if (passMatch) rem = rem.replace(passMatch[0], ' ');
      fullName = rem.replace(/\s+/g, ' ').trim();
    }

    if (!fullName || fullName.length < 3) {
      errors.push({ line, reason: "F.I.SH topilmadi yoki juda qisqa" });
      continue;
    }

    students.push({
      classId,
      fullName: capitalizeWords(fullName),
      passport: passport || 'KIRITILMAGAN',
      birthDate: birthDate || '',
      status: 'pending',
      paidAmount: 0,
    });
  }

  return { students, errors };
}

export function normalizeDate(dateStr: string): string {
  if (!dateStr) return '';
  const clean = dateStr.trim().replace(/[\/-]/g, '.');
  const parts = clean.split('.');
  if (parts.length === 3) {
    if (parts[0].length === 4) {
      // YYYY.MM.DD -> DD.MM.YYYY
      return `${parts[2].padStart(2, '0')}.${parts[1].padStart(2, '0')}.${parts[0]}`;
    }
    return `${parts[0].padStart(2, '0')}.${parts[1].padStart(2, '0')}.${parts[2]}`;
  }
  return dateStr;
}

export function capitalizeWords(str: string): string {
  return str
    .split(' ')
    .filter(Boolean)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Calculates finance metrics for a class group or entire school
 */
export function calculateFinanceMetrics(params: {
  studentCount: number;
  pricePerStudent: number;
  paidAmount: number;
}) {
  const totalDue = params.studentCount * params.pricePerStudent;
  const debt = Math.max(0, totalDue - params.paidAmount);
  let status: 'paid' | 'partial' | 'unpaid' = 'unpaid';

  if (params.paidAmount >= totalDue && totalDue > 0) {
    status = 'paid';
  } else if (params.paidAmount > 0) {
    status = 'partial';
  }

  return {
    totalDue,
    paidAmount: params.paidAmount,
    debt,
    status,
  };
}

/**
 * Generates ready-to-copy Telegram report text with emojis
 */
export function generateTelegramReport(options: {
  scopeName: string; // e.g. "Maktab bo'yicha" or "8-B sinf"
  totalStudents: number;
  certifiedCount: number;
  pendingCount: number;
  errorCount: number;
  totalPrice: number;
  paidAmount: number;
  debtAmount: number;
}): string {
  const nf = new Intl.NumberFormat('uz-UZ');
  return `🎓 ${options.scopeName.toUpperCase()} SERTIFIKAT NATIJALARI

📊 Jami o'quvchilar: ${options.totalStudents} nafar
🟢 Sertifikat olganlar: ${options.certifiedCount} nafar
⏳ Kutilmoqda: ${options.pendingCount} nafar${options.errorCount > 0 ? `\n⚠️ Xatolik aniqlangan: ${options.errorCount} nafar` : ''}

💰 To'lov: ${nf.format(options.paidAmount)} / ${nf.format(options.totalPrice)} so'm
🔴 Qarz: ${nf.format(options.debtAmount)} so'm

📅 Sana: ${new Date().toLocaleDateString('uz-UZ')}
⚡ Maktab Ta'lim Portali CRM orqali yaratildi`;
}

/**
 * Zero-Data-Loss Protection:
 * Prevents catastrophic wipe if incoming payload is empty while local database contains items.
 */
export function isSafeToOverwrite(
  currentDb: DatabaseState | null,
  incomingDb: DatabaseState | null,
  allowExplicitWipe: boolean = false
): { safe: boolean; reason?: string } {
  if (allowExplicitWipe) return { safe: true };
  if (!incomingDb) return { safe: false, reason: "Yangi ma'lumotlar bo'sh" };
  if (!currentDb) return { safe: true };

  const currentCount = currentDb.students.length + currentDb.classes.length;
  const incomingCount = incomingDb.students.length + incomingDb.classes.length;

  if (currentCount > 0 && incomingCount === 0) {
    return {
      safe: false,
      reason: `Mavjud bazada ${currentCount} ta yozuv bor, lekin kelgan baza bo'sh. Zero-Data-Loss himoyasi yoqildi!`,
    };
  }

  return { safe: true };
}
