import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { DatabaseState, ClassGroup, Student, TeacherCertificate } from '../types';
import { isSafeToOverwrite } from '../utils/logic';

const LOCAL_STORAGE_KEY = 'maktab_portal_db_v2';
const ADMIN_TOKEN_KEY = 'maktab_admin_token';
const ADMIN_EXPIRES_KEY = 'maktab_admin_token_expires';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message?: string;
}

interface DatabaseContextType {
  data: DatabaseState;
  isLoading: boolean;
  syncStatus: 'synced' | 'saving' | 'offline' | 'error';
  lastSavedAt: Date | null;
  isAdmin: boolean;
  adminLoginError: string | null;
  adminRemainingAttempts: number | null;
  adminLockedUntil: number | null;
  toasts: ToastMessage[];
  addToast: (type: 'success' | 'info' | 'warning' | 'error', title: string, message?: string) => void;
  removeToast: (id: string) => void;
  // Auth
  loginAsAdmin: (password: string) => Promise<boolean>;
  logoutAdmin: () => void;
  // Student Actions
  addStudent: (student: Omit<Student, 'id'>) => string;
  addStudentsBatch: (students: Omit<Student, 'id'>[]) => number;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  attachCertificate: (studentId: string, url: string) => boolean;
  attachToFirstPending: (classId?: string) => Promise<boolean>;
  // Class Actions
  addClass: (cls: Omit<ClassGroup, 'id'>) => string;
  updateClass: (id: string, updates: Partial<ClassGroup>) => void;
  deleteClass: (id: string) => void;
  // Teacher Actions
  addTeacher: (teacher: Omit<TeacherCertificate, 'id'>) => string;
  updateTeacher: (id: string, updates: Partial<TeacherCertificate>) => void;
  deleteTeacher: (id: string) => void;
  attachTeacherCertificate: (teacherId: string, url: string) => boolean;
  // Finance Actions
  markClassFullPaid: (classId: string) => void;
  updateClassPayment: (classId: string, paidAmount: number) => void;
  updateTeacherPayment: (teacherId: string, paidAmount: number) => void;
  // Settings & DB Actions
  updateSettings: (updates: Partial<DatabaseState['settings']>) => void;
  exportDatabaseJSON: () => void;
  importDatabaseJSON: (jsonStr: string) => boolean;
  resetToDefault: () => Promise<void>;
}

const DatabaseContext = createContext<DatabaseContextType | null>(null);

const DEFAULT_STATE: DatabaseState = {
  classes: [],
  students: [],
  teachers: [],
  settings: {
    defaultCertificatePrice: 10000,
    schoolName: "Prezident Ta'lim Muassasalari va Umumta'lim Maktabi",
    lastUpdated: new Date().toISOString(),
  },
};

export const DatabaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<DatabaseState>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed.classes && parsed.students) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed reading localStorage db', e);
    }
    return DEFAULT_STATE;
  });

  const [isLoading, setIsLoading] = useState(true);
  const [syncStatus, setSyncStatus] = useState<'synced' | 'saving' | 'offline' | 'error'>('synced');
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(new Date());
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Admin Auth state
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    try {
      const token = localStorage.getItem(ADMIN_TOKEN_KEY);
      const expires = localStorage.getItem(ADMIN_EXPIRES_KEY);
      if (token && expires && Number(expires) > Date.now()) {
        return true;
      }
    } catch {}
    return false;
  });
  const [adminLoginError, setAdminLoginError] = useState<string | null>(null);
  const [adminRemainingAttempts, setAdminRemainingAttempts] = useState<number | null>(null);
  const [adminLockedUntil, setAdminLockedUntil] = useState<number | null>(null);

  const syncTimeoutRef = useRef<any>(null);
  const latestDataRef = useRef<DatabaseState>(data);
  latestDataRef.current = data;

  const addToast = useCallback((type: 'success' | 'info' | 'warning' | 'error', title: string, message?: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Save to LocalStorage immediately and debounce server save
  const persistData = useCallback((newData: DatabaseState, forceEmpty: boolean = false) => {
    setData(newData);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newData));
    } catch (e) {
      console.error('LocalStorage write failed:', e);
    }

    setSyncStatus('saving');
    if (syncTimeoutRef.current) {
      clearTimeout(syncTimeoutRef.current);
    }

    syncTimeoutRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/data${forceEmpty ? '?forceEmpty=true' : ''}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newData),
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || 'Serverga saqlashda xatolik yuz berdi');
        }

        setSyncStatus('synced');
        setLastSavedAt(new Date());
      } catch (err: any) {
        console.warn('Backend sync failed, stored in LocalStorage:', err);
        setSyncStatus(navigator.onLine ? 'error' : 'offline');
      }
    }, 400);
  }, []);

  // Initial fetch from server
  useEffect(() => {
    let isMounted = true;
    async function initFetch() {
      try {
        const res = await fetch('/api/data');
        if (res.ok) {
          const remoteData: DatabaseState = await res.json();
          if (isMounted) {
            // Guard against wiping: check if remote data is empty while local has data
            const safety = isSafeToOverwrite(latestDataRef.current, remoteData);
            if (safety.safe) {
              if (remoteData.classes?.length || remoteData.students?.length) {
                setData(remoteData);
                try {
                  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(remoteData));
                } catch {}
              }
            } else {
              console.warn(safety.reason);
              // Push local data to server to keep it safe
              persistData(latestDataRef.current);
            }
          }
        }
      } catch (err) {
        console.warn('Initial server fetch failed, using local storage cache', err);
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    initFetch();
    return () => {
      isMounted = false;
      if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
    };
  }, [persistData]);

  // Admin Login
  const loginAsAdmin = async (password: string): Promise<boolean> => {
    setAdminLoginError(null);
    setAdminRemainingAttempts(null);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });

      const result = await res.json();
      if (!res.ok) {
        setAdminLoginError(result.error || 'Kirishda xatolik yuz berdi');
        if (result.remainingAttempts !== undefined) {
          setAdminRemainingAttempts(result.remainingAttempts);
        }
        if (result.lockedUntil) {
          setAdminLockedUntil(result.lockedUntil);
        }
        addToast('error', 'Kirish rad etildi', result.error);
        return false;
      }

      localStorage.setItem(ADMIN_TOKEN_KEY, result.token);
      localStorage.setItem(ADMIN_EXPIRES_KEY, String(result.expiresAt));
      setIsAdmin(true);
      addToast('success', 'Admin rejim faollashtirildi', 'Barcha boshqaruv imkoniyatlari ochildi');
      return true;
    } catch (err: any) {
      setAdminLoginError('Server bilan aloqa uzildi. Iltimos qayta urinib ko\'ring.');
      addToast('error', 'Server xatosi', err.message);
      return false;
    }
  };

  const logoutAdmin = () => {
    localStorage.removeItem(ADMIN_TOKEN_KEY);
    localStorage.removeItem(ADMIN_EXPIRES_KEY);
    setIsAdmin(false);
    addToast('info', 'Admin rejimdan chiqildi', 'Ustozlar portaliga qaytildi');
  };

  // Student CRUD
  const addStudent = (newStd: Omit<Student, 'id'>): string => {
    const id = `std-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const student: Student = { ...newStd, id };
    const updated = {
      ...latestDataRef.current,
      students: [student, ...latestDataRef.current.students],
    };
    persistData(updated);
    addToast('success', 'O\'quvchi qo\'shildi', student.fullName);
    return id;
  };

  const addStudentsBatch = (newStudents: Omit<Student, 'id'>[]): number => {
    if (!newStudents.length) return 0;
    const mapped: Student[] = newStudents.map((s, idx) => ({
      ...s,
      id: `std-batch-${Date.now()}-${idx}-${Math.random().toString(36).substr(2, 4)}`,
    }));
    const updated = {
      ...latestDataRef.current,
      students: [...mapped, ...latestDataRef.current.students],
    };
    persistData(updated);
    addToast('success', `${mapped.length} ta o'quvchi qo'shildi`, 'Baza yangilandi');
    return mapped.length;
  };

  const updateStudent = (id: string, updates: Partial<Student>) => {
    const updated = {
      ...latestDataRef.current,
      students: latestDataRef.current.students.map((s) =>
        s.id === id ? { ...s, ...updates } : s
      ),
    };
    persistData(updated);
    addToast('info', 'O\'quvchi ma\'lumotlari saqlandi');
  };

  const deleteStudent = (id: string) => {
    const target = latestDataRef.current.students.find((s) => s.id === id);
    const updated = {
      ...latestDataRef.current,
      students: latestDataRef.current.students.filter((s) => s.id !== id),
    };
    persistData(updated);
    addToast('warning', 'O\'quvchi o\'chirildi', target?.fullName);
  };

  const attachCertificate = (studentId: string, url: string): boolean => {
    if (!url || !url.trim()) return false;
    const trimmed = url.trim();
    const student = latestDataRef.current.students.find((s) => s.id === studentId);
    if (!student) return false;

    const updated = {
      ...latestDataRef.current,
      students: latestDataRef.current.students.map((s) =>
        s.id === studentId
          ? {
              ...s,
              certificateUrl: trimmed,
              status: 'certified' as const,
              certifiedAt: new Date().toISOString(),
            }
          : s
      ),
    };
    persistData(updated);
    addToast('success', 'Sertifikat biriktirildi! ✓', student.fullName);
    return true;
  };

  const attachToFirstPending = async (classId?: string): Promise<boolean> => {
    try {
      let clipboardText = '';
      if (navigator.clipboard && navigator.clipboard.readText) {
        clipboardText = await navigator.clipboard.readText();
      }
      if (!clipboardText || !clipboardText.trim()) {
        const prompted = window.prompt("Sertifikat havolasini (URL) kiriting:");
        if (!prompted) return false;
        clipboardText = prompted;
      }

      clipboardText = clipboardText.trim();
      if (!clipboardText) return false;

      // Find first pending student in class or whole list
      const candidate = latestDataRef.current.students.find(
        (s) => (!classId || s.classId === classId) && s.status === 'pending'
      );

      if (!candidate) {
        addToast('info', 'Kutilayotgan o\'quvchi topilmadi', 'Barcha o\'quvchilar sertifikat olgan');
        return false;
      }

      return attachCertificate(candidate.id, clipboardText);
    } catch (e: any) {
      addToast('error', 'Buferdan o\'qishda xatolik', e.message);
      return false;
    }
  };

  // Class CRUD
  const addClass = (cls: Omit<ClassGroup, 'id'>): string => {
    const id = `cls-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const newClass: ClassGroup = { ...cls, id };
    const updated = {
      ...latestDataRef.current,
      classes: [...latestDataRef.current.classes, newClass],
    };
    persistData(updated);
    addToast('success', 'Yangi sinf ochildi', newClass.name);
    return id;
  };

  const updateClass = (id: string, updates: Partial<ClassGroup>) => {
    const updated = {
      ...latestDataRef.current,
      classes: latestDataRef.current.classes.map((c) =>
        c.id === id ? { ...c, ...updates } : c
      ),
    };
    persistData(updated);
    addToast('info', 'Sinf yangilandi');
  };

  const deleteClass = (id: string) => {
    const target = latestDataRef.current.classes.find((c) => c.id === id);
    const updated = {
      ...latestDataRef.current,
      classes: latestDataRef.current.classes.filter((c) => c.id !== id),
      students: latestDataRef.current.students.filter((s) => s.classId !== id),
    };
    persistData(updated);
    addToast('warning', 'Sinf o\'chirildi', target?.name);
  };

  // Teacher CRUD
  const addTeacher = (teacher: Omit<TeacherCertificate, 'id'>): string => {
    const id = `tch-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const newTeacher: TeacherCertificate = { ...teacher, id };
    const updated = {
      ...latestDataRef.current,
      teachers: [newTeacher, ...latestDataRef.current.teachers],
    };
    persistData(updated);
    addToast('success', 'Ustoz sertifikati qo\'shildi', newTeacher.fullName);
    return id;
  };

  const updateTeacher = (id: string, updates: Partial<TeacherCertificate>) => {
    const updated = {
      ...latestDataRef.current,
      teachers: latestDataRef.current.teachers.map((t) =>
        t.id === id ? { ...t, ...updates } : t
      ),
    };
    persistData(updated);
    addToast('info', 'Ustoz ma\'lumotlari yangilandi');
  };

  const deleteTeacher = (id: string) => {
    const target = latestDataRef.current.teachers.find((t) => t.id === id);
    const updated = {
      ...latestDataRef.current,
      teachers: latestDataRef.current.teachers.filter((t) => t.id !== id),
    };
    persistData(updated);
    addToast('warning', 'Ustoz o\'chirildi', target?.fullName);
  };

  const attachTeacherCertificate = (teacherId: string, url: string): boolean => {
    if (!url || !url.trim()) return false;
    const teacher = latestDataRef.current.teachers.find((t) => t.id === teacherId);
    if (!teacher) return false;

    const updated = {
      ...latestDataRef.current,
      teachers: latestDataRef.current.teachers.map((t) =>
        t.id === teacherId
          ? {
              ...t,
              certificateUrl: url.trim(),
              status: 'certified' as const,
              certifiedAt: new Date().toISOString(),
            }
          : t
      ),
    };
    persistData(updated);
    addToast('success', 'Ustoz sertifikati biriktirildi! ✓', teacher.fullName);
    return true;
  };

  // Finance Actions
  const markClassFullPaid = (classId: string) => {
    const cls = latestDataRef.current.classes.find((c) => c.id === classId);
    if (!cls) return;
    const studentCount = latestDataRef.current.students.filter((s) => s.classId === classId).length;
    const fullAmount = studentCount * (cls.certificatePrice || 10000);

    const updated = {
      ...latestDataRef.current,
      classes: latestDataRef.current.classes.map((c) =>
        c.id === classId ? { ...c, paidAmount: fullAmount } : c
      ),
    };
    persistData(updated);
    addToast('success', `${cls.name} to'lovi to'liq tasdiqlandi! ✓`, `${new Intl.NumberFormat('uz-UZ').format(fullAmount)} so'm`);
  };

  const updateClassPayment = (classId: string, paidAmount: number) => {
    const updated = {
      ...latestDataRef.current,
      classes: latestDataRef.current.classes.map((c) =>
        c.id === classId ? { ...c, paidAmount: Math.max(0, paidAmount) } : c
      ),
    };
    persistData(updated);
    addToast('info', 'To\'lov summasi yangilandi');
  };

  const updateTeacherPayment = (teacherId: string, paidAmount: number) => {
    const updated = {
      ...latestDataRef.current,
      teachers: latestDataRef.current.teachers.map((t) =>
        t.id === teacherId ? { ...t, paidAmount: Math.max(0, paidAmount) } : t
      ),
    };
    persistData(updated);
    addToast('info', 'Ustoz to\'lovi yangilandi');
  };

  // Settings & JSON Backup
  const updateSettings = (updates: Partial<DatabaseState['settings']>) => {
    const updated = {
      ...latestDataRef.current,
      settings: { ...latestDataRef.current.settings, ...updates },
    };
    persistData(updated);
    addToast('info', 'Sozlamalar saqlandi');
  };

  const exportDatabaseJSON = () => {
    try {
      const jsonStr = JSON.stringify(latestDataRef.current, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `maktab_baza_${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
      addToast('success', 'Baza zaxira nusxasi yuklab olindi (.json)');
    } catch (e: any) {
      addToast('error', 'Eksportda xatolik', e.message);
    }
  };

  const importDatabaseJSON = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed || !Array.isArray(parsed.classes) || !Array.isArray(parsed.students)) {
        addToast('error', 'Fayl formati noto\'g\'ri', 'classes va students ro\'yxati topilmadi');
        return false;
      }

      const safety = isSafeToOverwrite(latestDataRef.current, parsed, true);
      if (!safety.safe) {
        addToast('error', 'Zero-Data-Loss himoyasi', safety.reason);
        return false;
      }

      persistData(parsed, true);
      addToast('success', 'Baza muvaffaqiyatli tiklandi!', `${parsed.classes.length} sinf, ${parsed.students.length} o'quvchi`);
      return true;
    } catch (e: any) {
      addToast('error', 'JSON o\'qishda xatolik', e.message);
      return false;
    }
  };

  const resetToDefault = async () => {
    try {
      const res = await fetch('/api/data?forceEmpty=true', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(DEFAULT_STATE),
      });
      if (res.ok) {
        // reload from initial
        window.location.reload();
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <DatabaseContext.Provider
      value={{
        data,
        isLoading,
        syncStatus,
        lastSavedAt,
        isAdmin,
        adminLoginError,
        adminRemainingAttempts,
        adminLockedUntil,
        toasts,
        addToast,
        removeToast,
        loginAsAdmin,
        logoutAdmin,
        addStudent,
        addStudentsBatch,
        updateStudent,
        deleteStudent,
        attachCertificate,
        attachToFirstPending,
        addClass,
        updateClass,
        deleteClass,
        addTeacher,
        updateTeacher,
        deleteTeacher,
        attachTeacherCertificate,
        markClassFullPaid,
        updateClassPayment,
        updateTeacherPayment,
        updateSettings,
        exportDatabaseJSON,
        importDatabaseJSON,
        resetToDefault,
      }}
    >
      {children}
    </DatabaseContext.Provider>
  );
};

export const useDatabase = () => {
  const context = useContext(DatabaseContext);
  if (!context) {
    throw new Error('useDatabase must be used within a DatabaseProvider');
  }
  return context;
};
