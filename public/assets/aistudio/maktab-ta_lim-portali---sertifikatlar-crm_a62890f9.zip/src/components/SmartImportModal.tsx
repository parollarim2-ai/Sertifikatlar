import React, { useState, useMemo, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { parseSmartStudentText } from '../utils/logic';
import {
  Sparkles,
  X,
  CheckCircle2,
  AlertTriangle,
  FileText,
  ArrowRight,
  Clipboard,
  Layers,
} from 'lucide-react';

interface SmartImportModalProps {
  isOpen: boolean;
  initialClassId: string;
  onClose: () => void;
}

export const SmartImportModal: React.FC<SmartImportModalProps> = ({
  isOpen,
  initialClassId,
  onClose,
}) => {
  const { data, addStudentsBatch } = useDatabase();
  const [selectedClassId, setSelectedClassId] = useState(initialClassId);
  const [rawText, setRawText] = useState('');

  useEffect(() => {
    setSelectedClassId(initialClassId);
  }, [initialClassId]);

  // ESC to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Live parser preview
  const parseResult = useMemo(() => {
    if (!rawText.trim()) {
      return { students: [], errors: [] };
    }
    return parseSmartStudentText(rawText, selectedClassId);
  }, [rawText, selectedClassId]);

  if (!isOpen) return null;

  const handleImport = () => {
    if (!parseResult.students.length) return;
    addStudentsBatch(parseResult.students);
    setRawText('');
    onClose();
  };

  const handleInsertSample = () => {
    const sample = `1. Abdullayev Jasur Shavkatovich | AA 1234567 | 15.03.2010
2. Karimova Zilola Otabek qizi | AB 9876543 | 22.07.2010
3. Xolmatov Bekzod Rustam o'g'li\tAC 5544332\t08.11.2009
4. Saidova Madina Ilhom qizi, AA7711223, 2010-04-19
5. Nazarov Shohruh Nodirovich I-TO 4567890 30.09.2010`;
    setRawText(sample);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-3xl max-h-[90vh] flex flex-col bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl rounded-3xl border border-white/60 dark:border-slate-800 shadow-2xl overflow-hidden text-slate-800 dark:text-slate-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="smart-import-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200/80 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-800/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 id="smart-import-title" className="text-base sm:text-lg font-bold tracking-tight">
                Smart Matn Importi (Telegram / Word / Excel)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Belgilar (| , tab - bo'shliq) orqali yozilgan matndan o'quvchilarni ajratib olish
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Yopish"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Target class selection */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-slate-500" />
              <label htmlFor="import-class-select" className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                O'quvchilar qo'shiladigan sinf:
              </label>
            </div>
            <select
              id="import-class-select"
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
              className="px-3.5 py-1.5 text-xs font-bold rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              {data.classes.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.name} sinfi ({cls.teacherName || 'Sinf rahbari yo\'q'})
                </option>
              ))}
            </select>
          </div>

          {/* Text input area */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Matnni shu yerga joylang:
              </span>
              <button
                type="button"
                onClick={handleInsertSample}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Namuna matnni kiritish
              </button>
            </div>
            <textarea
              rows={6}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder={`Masalan:\n1. Karimov Sanjar | AA1234567 | 15.03.2010\n2. Qodirova Malika AB7654321 2009-04-15\n3. Umarov Bekzod\tAC3344556\t01/01/2008`}
              className="w-full p-3.5 text-xs sm:text-sm font-mono bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Live Preview Section */}
          {rawText.trim() && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Jonli tekshiruv natijasi ({parseResult.students.length} ta o'quvchi aniqlandi):
                </span>
                {parseResult.errors.length > 0 && (
                  <span className="text-xs font-bold text-rose-500 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>{parseResult.errors.length} ta xato qator</span>
                  </span>
                )}
              </div>

              {parseResult.students.length > 0 && (
                <div className="max-h-52 overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-800 overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-100 dark:bg-slate-800 text-[10px] uppercase font-bold text-slate-500">
                        <th className="p-2.5">№</th>
                        <th className="p-2.5">F.I.SH</th>
                        <th className="p-2.5">Pasport</th>
                        <th className="p-2.5">Tug'ilgan sana</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {parseResult.students.map((s, idx) => (
                        <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                          <td className="p-2.5 font-mono text-slate-400">{idx + 1}</td>
                          <td className="p-2.5 font-semibold text-slate-800 dark:text-slate-200">
                            {s.fullName}
                          </td>
                          <td className="p-2.5 font-mono text-blue-600 dark:text-blue-400">
                            {s.passport}
                          </td>
                          <td className="p-2.5 font-mono text-slate-600 dark:text-slate-400">
                            {s.birthDate || '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {parseResult.errors.length > 0 && (
                <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs space-y-1">
                  <p className="font-bold">Quyidagi qatorlar tushunarsiz:</p>
                  {parseResult.errors.map((err, i) => (
                    <p key={i} className="font-mono text-[11px] truncate">
                      • "{err.line}" — {err.reason}
                    </p>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between p-4 border-t border-slate-200/80 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-800/30">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
          >
            Bekor qilish
          </button>

          <button
            type="button"
            onClick={handleImport}
            disabled={!parseResult.students.length}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:pointer-events-none shadow-md shadow-indigo-600/25 transition-all active:scale-95"
          >
            <span>{parseResult.students.length} ta O'quvchini Bazaga Qo'shish</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
