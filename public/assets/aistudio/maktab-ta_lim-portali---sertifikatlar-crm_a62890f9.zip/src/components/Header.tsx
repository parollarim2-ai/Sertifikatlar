import React from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { generateTelegramReport } from '../utils/logic';
import {
  GraduationCap,
  ShieldCheck,
  Send,
  CloudCheck,
  CloudUpload,
  WifiOff,
  Lock,
  Unlock,
  Download,
  Users,
  Award,
  CircleDollarSign,
} from 'lucide-react';

interface HeaderProps {
  currentTab: 'students' | 'teachers' | 'finance';
  onSelectTab: (tab: 'students' | 'teachers' | 'finance') => void;
  onOpenAdminLogin: () => void;
  onOpenBackupModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  onOpenAdminLogin,
  onOpenBackupModal,
}) => {
  const { data, syncStatus, isAdmin, logoutAdmin, addToast } = useDatabase();

  const handleCopySchoolTelegramReport = () => {
    const totalStudents = data.students.length;
    const certifiedCount = data.students.filter((s) => s.status === 'certified').length;
    const pendingCount = data.students.filter((s) => s.status === 'pending').length;
    const errorCount = data.students.filter((s) => s.status === 'error').length;

    // Calculate total price and payments across classes
    let totalPrice = 0;
    let paidAmount = 0;
    for (const cls of data.classes) {
      const clsStudents = data.students.filter((s) => s.classId === cls.id).length;
      totalPrice += clsStudents * (cls.certificatePrice || 10000);
      paidAmount += cls.paidAmount || 0;
    }
    const debtAmount = Math.max(0, totalPrice - paidAmount);

    const reportText = generateTelegramReport({
      scopeName: data.settings?.schoolName || "Maktab Ta'lim Portali",
      totalStudents,
      certifiedCount,
      pendingCount,
      errorCount,
      totalPrice,
      paidAmount,
      debtAmount,
    });

    navigator.clipboard.writeText(reportText).then(() => {
      addToast(
        'success',
        'Telegram hisoboti nusxalandi! 📋',
        "Maktab guruhiga tashlash uchun to'liq hisobot buferga olindi"
      );
    }).catch(() => {
      window.prompt("Hisobot matnini nusxalang:", reportText);
    });
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-2xl bg-white/75 dark:bg-slate-900/80 border-b border-slate-200/60 dark:border-slate-800/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-blue-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20 shrink-0">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-lg tracking-tight text-slate-900 dark:text-white leading-none">
                  Maktab Ta'lim Portali
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300">
                  CRM Pro
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 truncate max-w-[200px] sm:max-w-xs">
                {data.settings?.schoolName || "Sertifikatlar monitoringi tizimi"}
              </p>
            </div>
          </div>

          {/* Center Tabs: Navigation */}
          <nav className="hidden md:flex items-center p-1.5 rounded-2xl bg-slate-100/80 dark:bg-slate-800/80 border border-slate-200/50 dark:border-slate-700/50">
            <button
              onClick={() => onSelectTab('students')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentTab === 'students'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>O'quvchilar & Sinflar</span>
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                {data.students.length}
              </span>
            </button>

            <button
              onClick={() => onSelectTab('teachers')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentTab === 'teachers'
                  ? 'bg-purple-600 text-white shadow-xs shadow-purple-600/30'
                  : 'text-purple-700 dark:text-purple-300 hover:text-purple-900 dark:hover:text-purple-100 hover:bg-purple-50 dark:hover:bg-purple-950/30'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>Ustozlar Sertifikatlari</span>
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-purple-200/80 text-purple-900 dark:bg-purple-900 dark:text-purple-100">
                {data.teachers.length}
              </span>
            </button>

            <button
              onClick={() => onSelectTab('finance')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentTab === 'finance'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <CircleDollarSign className="w-4 h-4" />
              <span>Moliya Matritsasi</span>
            </button>
          </nav>

          {/* Right Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Sync Badge */}
            <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/60 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800/40">
              {syncStatus === 'synced' && (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <CloudCheck className="w-3.5 h-3.5" />
                  <span>Zero-Data-Loss Faol</span>
                </>
              )}
              {syncStatus === 'saving' && (
                <>
                  <CloudUpload className="w-3.5 h-3.5 animate-bounce text-blue-500" />
                  <span className="text-blue-600 dark:text-blue-400">Saqlanmoqda...</span>
                </>
              )}
              {syncStatus === 'offline' && (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-500" />
                  <span className="text-amber-600">Lokal Saqlandi</span>
                </>
              )}
            </div>

            {/* Telegram Hisobot Button */}
            <button
              onClick={handleCopySchoolTelegramReport}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200/70 dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-800/40 transition-colors shadow-xs active:scale-95"
              title="Maktab bo'yicha chiroyli Telegram hisobotini buferga olish"
            >
              <Send className="w-3.5 h-3.5 text-sky-500" />
              <span className="hidden sm:inline">Telegramga Hisobot</span>
            </button>

            {/* Backup & Restore Dialog Trigger */}
            <button
              onClick={onOpenBackupModal}
              className="p-2 rounded-xl text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white bg-slate-100/80 hover:bg-slate-200/80 dark:bg-slate-800/80 dark:hover:bg-slate-700/80 border border-slate-200/60 dark:border-slate-700/60 transition-colors"
              title="Baza zaxira nusxasi (Backup / Restore)"
              aria-label="Baza zaxira nusxasi"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Admin Toggle / Login Button */}
            {isAdmin ? (
              <div className="flex items-center gap-2">
                <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold bg-amber-500/10 text-amber-600 border border-amber-500/20">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                  Admin
                </span>
                <button
                  onClick={logoutAdmin}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-900 transition-colors"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Chiqish</span>
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAdminLogin}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 shadow-md shadow-slate-900/10 transition-all active:scale-95"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Boshqaruv (Admin)</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-200/60 dark:border-slate-800">
          <button
            onClick={() => onSelectTab('students')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium ${
              currentTab === 'students'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 font-semibold'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Sinflar ({data.students.length})</span>
          </button>
          <button
            onClick={() => onSelectTab('teachers')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium ${
              currentTab === 'teachers'
                ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 font-semibold'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Award className="w-3.5 h-3.5 text-purple-600" />
            <span>Ustozlar ({data.teachers.length})</span>
          </button>
          <button
            onClick={() => onSelectTab('finance')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium ${
              currentTab === 'finance'
                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-semibold'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <CircleDollarSign className="w-3.5 h-3.5 text-emerald-600" />
            <span>Moliya</span>
          </button>
        </div>
      </div>
    </header>
  );
};
