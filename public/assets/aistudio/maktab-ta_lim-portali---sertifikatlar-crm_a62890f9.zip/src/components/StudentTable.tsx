import React, { useState, useMemo, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { Student } from '../types';
import { extractPassport7Digits, generateTelegramReport } from '../utils/logic';
import {
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  ExternalLink,
  ClipboardCopy,
  ClipboardPaste,
  Edit2,
  Trash2,
  UserPlus,
  FileSpreadsheet,
  FileText,
  Send,
  Sparkles,
  Zap,
} from 'lucide-react';

interface StudentTableProps {
  classId: string;
  onOpenAddStudent: () => void;
  onOpenSmartImport: () => void;
  onEditStudent: (student: Student) => void;
}

export const StudentTable: React.FC<StudentTableProps> = ({
  classId,
  onOpenAddStudent,
  onOpenSmartImport,
  onEditStudent,
}) => {
  const {
    data,
    attachCertificate,
    attachToFirstPending,
    deleteStudent,
    isAdmin,
    addToast,
  } = useDatabase();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'certified' | 'pending' | 'error'>('all');

  const currentClass = data.classes.find((c) => c.id === classId);
  const classStudents = useMemo(() => {
    return data.students.filter((s) => s.classId === classId);
  }, [data.students, classId]);

  // Global Keyboard shortcut: Alt + V for fastest certificate pasting!
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'v' || e.key === 'V' || e.code === 'KeyV')) {
        e.preventDefault();
        attachToFirstPending(classId);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [attachToFirstPending, classId]);

  // Filter and search
  const filteredStudents = useMemo(() => {
    return classStudents.filter((student) => {
      const matchesSearch =
        student.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.passport.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesStatus =
        statusFilter === 'all' || student.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [classStudents, searchQuery, statusFilter]);

  // 1-Click Passport copy handlers
  const handleCopy7Digits = (e: React.MouseEvent, passport: string, name: string) => {
    e.stopPropagation();
    const digits = extractPassport7Digits(passport);
    if (!digits) {
      addToast('warning', 'Pasport raqami topilmadi');
      return;
    }
    navigator.clipboard.writeText(digits).then(() => {
      addToast('success', `7 xonali raqam nusxalandi: ${digits}`, `${name} uchun portalga kiritishga tayyor`);
    }).catch(() => {
      window.prompt("7 xonali raqamni nusxalang:", digits);
    });
  };

  const handleCopyFullPassport = (e: React.MouseEvent, passport: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(passport).then(() => {
      addToast('info', `To'liq seriya nusxalandi: ${passport}`);
    }).catch(() => {
      window.prompt("Pasport seriyasini nusxalang:", passport);
    });
  };

  // 1-Click Paste Certificate
  const handlePasteCertificate = async (e: React.MouseEvent, studentId: string) => {
    e.stopPropagation();
    try {
      let clipboardText = '';
      if (navigator.clipboard && navigator.clipboard.readText) {
        try {
          clipboardText = await navigator.clipboard.readText();
        } catch {
          // Fallback if browser permission is not granted
        }
      }

      if (!clipboardText || !clipboardText.trim()) {
        const input = window.prompt("Sertifikat havolasini (URL) kiriting:");
        if (!input) return;
        clipboardText = input;
      }

      if (clipboardText.trim()) {
        attachCertificate(studentId, clipboardText.trim());
      }
    } catch (err: any) {
      addToast('error', 'Xatolik', err.message);
    }
  };

  // Telegram report for current class
  const handleCopyClassTelegramReport = () => {
    if (!currentClass) return;
    const totalStudents = classStudents.length;
    const certifiedCount = classStudents.filter((s) => s.status === 'certified').length;
    const pendingCount = classStudents.filter((s) => s.status === 'pending').length;
    const errorCount = classStudents.filter((s) => s.status === 'error').length;
    const totalPrice = totalStudents * (currentClass.certificatePrice || 10000);
    const paidAmount = currentClass.paidAmount || 0;
    const debtAmount = Math.max(0, totalPrice - paidAmount);

    const reportText = generateTelegramReport({
      scopeName: `${currentClass.name} sinf`,
      totalStudents,
      certifiedCount,
      pendingCount,
      errorCount,
      totalPrice,
      paidAmount,
      debtAmount,
    });

    navigator.clipboard.writeText(reportText).then(() => {
      addToast(
        'success',
        `${currentClass.name} Telegram hisoboti nusxalandi! 📋`,
        "Sinf ota-onalar yoki ustozlar guruhiga tashlashga tayyor"
      );
    }).catch(() => {
      window.prompt("Hisobot matnini nusxalang:", reportText);
    });
  };

  // Excel / CSV Export with UTF-8 BOM
  const handleExportCSV = () => {
    if (!classStudents.length || !currentClass) {
      addToast('warning', 'Eksport qilish uchun o\'quvchilar mavjud emas');
      return;
    }

    const headers = ['№', 'F.I.SH', 'Pasport / Metrika', 'Tug\'ilgan sana', 'Holat', 'Sertifikat URL', 'Olingan sana'];
    const rows = classStudents.map((s, idx) => [
      idx + 1,
      `"${s.fullName.replace(/"/g, '""')}"`,
      `"${s.passport}"`,
      `"${s.birthDate || ''}"`,
      s.status === 'certified' ? 'Tayyor' : s.status === 'error' ? 'Xatolik' : 'Kutilmoqda',
      `"${s.certificateUrl || ''}"`,
      `"${s.certifiedAt ? new Date(s.certifiedAt).toLocaleString('uz-UZ') : ''}"`,
    ]);

    // Prepend UTF-8 BOM (\uFEFF) to guarantee Excel reads Uzbek characters correctly
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentClass.name}_o'quvchilar_sertifikatlar_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    addToast('success', 'Excel (CSV) muvaffaqiyatli yuklandi', `${currentClass.name} sinfi`);
  };

  const certifiedCount = classStudents.filter((s) => s.status === 'certified').length;
  const pendingCount = classStudents.filter((s) => s.status === 'pending').length;
  const errorCount = classStudents.filter((s) => s.status === 'error').length;

  return (
    <div className="w-full space-y-4">
      {/* Control Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 p-4 rounded-3xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-xs">
        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 flex-1">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="F.I.SH yoki pasport bo'yicha qidirish..."
              className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-2xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 p-1 bg-slate-100/90 dark:bg-slate-800/80 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                statusFilter === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Barchasi ({classStudents.length})
            </button>
            <button
              onClick={() => setStatusFilter('certified')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                statusFilter === 'certified'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Tayyor ({certifiedCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('pending')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                statusFilter === 'pending'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Kutilmoqda ({pendingCount})</span>
            </button>
            {errorCount > 0 && (
              <button
                onClick={() => setStatusFilter('error')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  statusFilter === 'error'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                }`}
              >
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Xatolik ({errorCount})</span>
              </button>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Alt+V Speed tool button */}
          <button
            onClick={() => attachToFirstPending(classId)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/50 dark:hover:bg-amber-900/60 border border-amber-300/70 dark:border-amber-700/60 transition-all shadow-xs"
            title="Klaviatura: Alt + V tugmasi ham ishlaydi"
          >
            <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span>[Alt + V] Tezkor Biriktirish</span>
          </button>

          {/* Telegram Report for this class */}
          <button
            onClick={handleCopyClassTelegramReport}
            className="flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-semibold text-sky-700 dark:text-sky-300 bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/50 dark:hover:bg-sky-900/60 border border-sky-200 dark:border-sky-800/60 transition-all shadow-xs"
            title="Sinf bo'yicha Telegram hisobotini nusxalash"
          >
            <Send className="w-3.5 h-3.5 text-sky-500" />
            <span className="hidden sm:inline">Telegramga Hisobot</span>
          </button>

          {/* Excel Export */}
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200/80 dark:border-slate-700 transition-all shadow-xs"
            title="Excel formatida yuklab olish (UTF-8 BOM)"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Excel (CSV)</span>
          </button>

          {/* Smart Text Import */}
          <button
            onClick={onOpenSmartImport}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/60 border border-indigo-200 dark:border-indigo-800/60 transition-all shadow-xs"
            title="Telegram yoki Worddan ommaviy matn kiritish"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Smart Import</span>
          </button>

          {/* Add Student */}
          <button
            onClick={onOpenAddStudent}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:scale-95 shadow-md shadow-blue-600/25 transition-all"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>+ O'quvchi</span>
          </button>
        </div>
      </div>

      {/* Main Student List Table */}
      <div className="overflow-hidden rounded-3xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200/80 dark:border-slate-800/80 bg-slate-50/60 dark:bg-slate-800/40 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                <th className="py-3.5 px-4 w-12 text-center">№</th>
                <th className="py-3.5 px-4 min-w-[200px]">F.I.SH (O'quvchi)</th>
                <th className="py-3.5 px-4 min-w-[160px]">Pasport / Metrika</th>
                <th className="py-3.5 px-4 min-w-[110px]">Tug'ilgan sana</th>
                <th className="py-3.5 px-4 min-w-[140px]">Holat</th>
                <th className="py-3.5 px-4 min-w-[190px]">Sertifikat havolasi</th>
                <th className="py-3.5 px-4 w-28 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs sm:text-sm">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <div className="max-w-xs mx-auto space-y-2">
                      <FileText className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600" />
                      <p className="font-semibold text-slate-600 dark:text-slate-300">
                        O'quvchilar topilmadi
                      </p>
                      <p className="text-xs text-slate-400">
                        {searchQuery
                          ? 'Qidiruv bo\'yicha hech qanday natija yo\'q'
                          : 'Ushbu sinfda hali o\'quvchilar yo\'q. "+ O\'quvchi" yoki "Smart Import" tugmasini bosing'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student, idx) => {
                  const isCertified = student.status === 'certified';
                  const isPending = student.status === 'pending';
                  const isError = student.status === 'error';
                  const sevenDigits = extractPassport7Digits(student.passport);

                  return (
                    <tr
                      key={student.id}
                      onClick={() => onEditStudent(student)}
                      className="group hover:bg-blue-50/40 dark:hover:bg-slate-800/40 transition-colors cursor-pointer"
                    >
                      {/* Index */}
                      <td className="py-3.5 px-4 text-center font-mono text-xs text-slate-400">
                        {idx + 1}
                      </td>

                      {/* Full Name */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                          {student.fullName}
                        </div>
                        {isError && student.errorReason && (
                          <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-0.5 font-medium flex items-center gap-1">
                            <AlertCircle className="w-3 h-3 shrink-0" />
                            <span>{student.errorReason}</span>
                          </p>
                        )}
                      </td>

                      {/* Passport with 1-click copy */}
                      <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={(e) => handleCopy7Digits(e, student.passport, student.fullName)}
                            title="Bir bosishda faqat 7 xonali raqamni nusxalash (Portalga kiritish uchun)"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl font-mono text-xs font-bold bg-slate-100 hover:bg-blue-100 text-slate-800 dark:bg-slate-800 dark:hover:bg-blue-950 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-all hover:scale-105 active:scale-95"
                          >
                            <span>{student.passport}</span>
                            <ClipboardCopy className="w-3 h-3 text-slate-400 group-hover:text-blue-500" />
                          </button>

                          <button
                            onClick={(e) => handleCopyFullPassport(e, student.passport)}
                            title="To'liq seriyani nusxalash"
                            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          >
                            <span className="text-[10px] font-bold uppercase">To'liq</span>
                          </button>
                        </div>
                      </td>

                      {/* Birth Date */}
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-300">
                        {student.birthDate || '—'}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        {isCertified && (
                          <div className="space-y-0.5">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                              <span>Sertifikat tayyor</span>
                            </span>
                            {student.certifiedAt && (
                              <div className="text-[10px] font-mono text-slate-400">
                                {new Date(student.certifiedAt).toLocaleString('uz-UZ', {
                                  month: '2-digit',
                                  day: '2-digit',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit',
                                })}
                              </div>
                            )}
                          </div>
                        )}

                        {isPending && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                            <span>Kutilmoqda</span>
                          </span>
                        )}

                        {isError && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                            <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                            <span>Xatolik</span>
                          </span>
                        )}
                      </td>

                      {/* Certificate URL & 1-Click Paste button */}
                      <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                        {student.certificateUrl ? (
                          <div className="flex items-center gap-2">
                            <a
                              href={student.certificateUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 transition-colors"
                              title={student.certificateUrl}
                            >
                              <span>Ko'rish</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                            <button
                              onClick={(e) => handlePasteCertificate(e, student.id)}
                              className="p-1 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors"
                              title="Havolani yangilash"
                            >
                              <ClipboardPaste className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={(e) => handlePasteCertificate(e, student.id)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100/80 hover:bg-emerald-200/90 dark:bg-emerald-950/70 dark:hover:bg-emerald-900/80 border border-emerald-300 dark:border-emerald-700 transition-all hover:scale-105 active:scale-95 shadow-xs"
                            title="Buferdagi nusxalangan havolani biriktirish va 'Tayyor' qilish"
                          >
                            <ClipboardPaste className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                            <span>[📋 Qo'yish]</span>
                          </button>
                        )}
                      </td>

                      {/* Row Actions */}
                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onEditStudent(student)}
                            className="p-1.5 rounded-xl text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors"
                            title="Tahrirlash"
                            aria-label={`Tahrirlash ${student.fullName}`}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {isAdmin && (
                            <button
                              onClick={() => {
                                if (window.confirm(`${student.fullName} bazadan o'chirilsinmi?`)) {
                                  deleteStudent(student.id);
                                }
                              }}
                              className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                              title="O'chirish (Admin)"
                              aria-label={`O'chirish ${student.fullName}`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info bar */}
        <div className="p-3.5 border-t border-slate-200/80 dark:border-slate-800/80 bg-slate-50/60 dark:bg-slate-800/40 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <span>
              Jami ko'rsatilmoqda: <strong className="text-slate-800 dark:text-slate-200">{filteredStudents.length}</strong> nafar
            </span>
            <span className="h-3 w-px bg-slate-300 dark:bg-slate-700" />
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
              Tayyor: {certifiedCount}
            </span>
            <span className="text-amber-600 dark:text-amber-400 font-semibold">
              Kutilmoqda: {pendingCount}
            </span>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span className="px-1.5 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 font-mono text-[10px]">Alt + V</span>
            <span>Tezkor sertifikat qo'yish</span>
            <span className="h-3 w-px bg-slate-300 dark:bg-slate-700" />
            <span>Pasport ustiga bosilsa 7 xonali raqam nusxalanadi</span>
          </div>
        </div>
      </div>
    </div>
  );
};
