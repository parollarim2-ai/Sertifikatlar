import React from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { ClassGroup } from '../types';
import { Plus, CheckCircle, Clock, AlertTriangle, Phone, UserCheck, Edit3 } from 'lucide-react';

interface ClassTabsProps {
  selectedClassId: string;
  onSelectClass: (classId: string) => void;
  onOpenAddClass: () => void;
  onOpenEditClass: (cls: ClassGroup) => void;
}

export const ClassTabs: React.FC<ClassTabsProps> = ({
  selectedClassId,
  onSelectClass,
  onOpenAddClass,
  onOpenEditClass,
}) => {
  const { data, isAdmin } = useDatabase();

  const selectedClass = data.classes.find((c) => c.id === selectedClassId) || data.classes[0];

  return (
    <div className="w-full space-y-4">
      {/* Scrollable Class Tabs bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
        {data.classes.map((cls) => {
          const classStudents = data.students.filter((s) => s.classId === cls.id);
          const totalCount = classStudents.length;
          const certifiedCount = classStudents.filter((s) => s.status === 'certified').length;
          const hasError = classStudents.some((s) => s.status === 'error');
          const isSelected = cls.id === selectedClassId;

          // Payment status
          const totalDue = totalCount * (cls.certificatePrice || 10000);
          const isPaid = (cls.paidAmount || 0) >= totalDue && totalDue > 0;
          const isPartial = (cls.paidAmount || 0) > 0 && !isPaid;

          return (
            <button
              key={cls.id}
              onClick={() => onSelectClass(cls.id)}
              className={`group shrink-0 relative flex items-center gap-2.5 px-4 py-2.5 rounded-2xl text-sm font-semibold transition-all duration-200 ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 ring-2 ring-blue-600/50 scale-[1.02]'
                  : 'bg-white/80 dark:bg-slate-900/80 hover:bg-white dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200/80 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700 shadow-xs'
              }`}
            >
              <span className="text-base font-bold tracking-tight">{cls.name}</span>

              {/* Progress Count Badge */}
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold ${
                  isSelected
                    ? 'bg-white/20 text-white'
                    : certifiedCount === totalCount && totalCount > 0
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                {certifiedCount === totalCount && totalCount > 0 ? (
                  <CheckCircle className="w-3 h-3 text-emerald-400" />
                ) : hasError ? (
                  <AlertTriangle className="w-3 h-3 text-rose-400" />
                ) : (
                  <Clock className="w-3 h-3 text-amber-400" />
                )}
                <span>
                  {certifiedCount}/{totalCount}
                </span>
              </span>

              {/* Payment dot */}
              <span
                title={isPaid ? "To'liq to'langan" : isPartial ? "Qisman to'langan" : "To'lanmagan"}
                className={`w-2 h-2 rounded-full ${
                  isPaid ? 'bg-emerald-400 ring-2 ring-emerald-300/40' : isPartial ? 'bg-amber-400' : 'bg-rose-400'
                }`}
              />
            </button>
          );
        })}

        {isAdmin && (
          <button
            onClick={onOpenAddClass}
            className="shrink-0 flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-bold text-blue-700 dark:text-blue-300 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 dark:hover:bg-blue-900/50 border border-dashed border-blue-300 dark:border-blue-800 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Yangi Sinf Qo'shish</span>
          </button>
        )}
      </div>

      {/* Selected Class Teacher & Summary Banner */}
      {selectedClass && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl border border-slate-200/70 dark:border-slate-800/70 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200/60 dark:border-blue-800/60 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
                  {selectedClass.name} sinf rahbari:
                </span>
                <span className="text-sm font-semibold text-blue-700 dark:text-blue-300">
                  {selectedClass.teacherName || "Tayinlanmagan"}
                </span>
                {isAdmin && (
                  <button
                    onClick={() => onOpenEditClass(selectedClass)}
                    className="p-1 rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors"
                    title="Sinf ma'lumotlarini tahrirlash"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              {selectedClass.teacherPhone && (
                <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  <Phone className="w-3 h-3 text-slate-400" />
                  <span>{selectedClass.teacherPhone}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium text-slate-600 dark:text-slate-300">
            <div>
              <span className="text-slate-400">Sertifikat narxi: </span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {new Intl.NumberFormat('uz-UZ').format(selectedClass.certificatePrice || 10000)} so'm
              </span>
            </div>
            <div className="h-4 w-px bg-slate-200 dark:bg-slate-800" />
            <div>
              <span className="text-slate-400">To'langan: </span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">
                {new Intl.NumberFormat('uz-UZ').format(selectedClass.paidAmount || 0)} so'm
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
