import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { Student, StudentStatus } from '../types';
import { formatFullPassport, normalizeDate } from '../utils/logic';
import {
  X,
  User,
  CreditCard,
  Calendar,
  Award,
  AlertTriangle,
  Link as LinkIcon,
  CheckCircle2,
  Clock,
  Layers,
  ClipboardPaste,
} from 'lucide-react';

interface EditStudentModalProps {
  isOpen: boolean;
  student: Student | null; // null means create new
  defaultClassId: string;
  onClose: () => void;
}

export const EditStudentModal: React.FC<EditStudentModalProps> = ({
  isOpen,
  student,
  defaultClassId,
  onClose,
}) => {
  const { data, addStudent, updateStudent, addToast } = useDatabase();

  const [classId, setClassId] = useState(defaultClassId);
  const [fullName, setFullName] = useState('');
  const [passport, setPassport] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [status, setStatus] = useState<StudentStatus>('pending');
  const [certificateUrl, setCertificateUrl] = useState('');
  const [errorReason, setErrorReason] = useState('');

  useEffect(() => {
    if (student) {
      setClassId(student.classId);
      setFullName(student.fullName);
      setPassport(student.passport);
      setBirthDate(student.birthDate || '');
      setStatus(student.status);
      setCertificateUrl(student.certificateUrl || '');
      setErrorReason(student.errorReason || '');
    } else {
      setClassId(defaultClassId);
      setFullName('');
      setPassport('');
      setBirthDate('');
      setStatus('pending');
      setCertificateUrl('');
      setErrorReason('');
    }
  }, [student, defaultClassId, isOpen]);

  // ESC to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handlePasteUrl = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text) {
          setCertificateUrl(text.trim());
          setStatus('certified');
          addToast('info', 'Havola buferdan qo\'yildi');
        }
      }
    } catch {
      const prompted = window.prompt("Sertifikat havolasini kiriting:");
      if (prompted) {
        setCertificateUrl(prompted.trim());
        setStatus('certified');
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      addToast('warning', 'O\'quvchi F.I.SH kiritilishi shart');
      return;
    }

    const payload = {
      classId,
      fullName: fullName.trim(),
      passport: formatFullPassport(passport) || 'KIRITILMAGAN',
      birthDate: normalizeDate(birthDate),
      status,
      certificateUrl: certificateUrl.trim() || undefined,
      certifiedAt: status === 'certified' ? (student?.certifiedAt || new Date().toISOString()) : undefined,
      paidAmount: student?.paidAmount || 0,
      errorReason: status === 'error' ? errorReason.trim() : undefined,
    };

    if (student) {
      updateStudent(student.id, payload);
    } else {
      addStudent(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl rounded-3xl border border-white/60 dark:border-slate-800 shadow-2xl p-6 sm:p-7 text-slate-800 dark:text-slate-100 relative max-h-[90vh] overflow-y-auto"
        role="dialog"
        aria-modal="true"
        aria-labelledby="student-modal-title"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Yopish"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
            <User className="w-6 h-6" />
          </div>
          <div>
            <h2 id="student-modal-title" className="text-lg font-bold tracking-tight">
              {student ? 'O\'quvchi Ma\'lumotlarini Tahrirlash' : 'Yangi O\'quvchi Qo\'shish'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              O'quvchi ma'lumotlari to'g'ridan-to'g'ri bulutli bazaga saqlanadi
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Class selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-slate-400" />
              <span>Sinf</span>
            </label>
            <select
              value={classId}
              onChange={(e) => setClassId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white text-sm font-semibold focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {data.classes.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.name} sinfi
                </option>
              ))}
            </select>
          </div>

          {/* Full Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span>F.I.SH (To'liq ismi)</span>
            </label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Masalan: Abdullayev Sardor Jasur o'g'li"
              required
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          {/* Passport & Birthdate row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-slate-400" />
                <span>Pasport / Metrika</span>
              </label>
              <input
                type="text"
                value={passport}
                onChange={(e) => setPassport(e.target.value.toUpperCase())}
                placeholder="AA1234567"
                className="w-full px-3.5 py-2.5 font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Tug'ilgan sana</span>
              </label>
              <input
                type="text"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                placeholder="15.03.2010"
                className="w-full px-3.5 py-2.5 font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          {/* Status selector pills */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-slate-400" />
              <span>Sertifikat holati</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setStatus('certified')}
                className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-2xl text-xs font-bold border transition-all ${
                  status === 'certified'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                    : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Tayyor</span>
              </button>

              <button
                type="button"
                onClick={() => setStatus('pending')}
                className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-2xl text-xs font-bold border transition-all ${
                  status === 'pending'
                    ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                    : 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800 hover:bg-amber-100'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Kutilmoqda</span>
              </button>

              <button
                type="button"
                onClick={() => setStatus('error')}
                className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-2xl text-xs font-bold border transition-all ${
                  status === 'error'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                    : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800 hover:bg-rose-100'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Xatolik</span>
              </button>
            </div>
          </div>

          {/* Certificate URL */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <LinkIcon className="w-3.5 h-3.5 text-slate-400" />
                <span>Sertifikat Havolasi (URL)</span>
              </label>
              <button
                type="button"
                onClick={handlePasteUrl}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
              >
                <ClipboardPaste className="w-3.5 h-3.5" />
                <span>[📋 Buferdan Qo'yish]</span>
              </button>
            </div>
            <input
              type="url"
              value={certificateUrl}
              onChange={(e) => {
                setCertificateUrl(e.target.value);
                if (e.target.value.trim() && status === 'pending') {
                  setStatus('certified');
                }
              }}
              placeholder="https://cert.maktab.uz/verify/..."
              className="w-full px-3.5 py-2.5 font-mono text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          {/* Error Reason input if status === 'error' */}
          {status === 'error' && (
            <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 space-y-2">
              <label className="block text-xs font-bold text-rose-700 dark:text-rose-300">
                Xatolik sababi va izohi:
              </label>
              <input
                type="text"
                value={errorReason}
                onChange={(e) => setErrorReason(e.target.value)}
                placeholder="Masalan: Metrika seriyasida raqam xato kiritilgan"
                className="w-full px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-900 border border-rose-300 dark:border-rose-700 text-rose-900 dark:text-rose-100 outline-none"
              />
            </div>
          )}

          {/* Submit buttons */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200/80 dark:border-slate-800/80">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:scale-95 shadow-lg shadow-blue-600/25 transition-all"
            >
              Bazaga Saqlash
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
