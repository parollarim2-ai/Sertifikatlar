import React, { useRef, useState } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import {
  Download,
  Upload,
  ShieldCheck,
  RotateCcw,
  X,
  FileJson,
  Database,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BackupModal: React.FC<BackupModalProps> = ({ isOpen, onClose }) => {
  const {
    data,
    exportDatabaseJSON,
    importDatabaseJSON,
    resetToDefault,
    isAdmin,
    addToast,
  } = useDatabase();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        if (content) {
          const success = importDatabaseJSON(content);
          if (success) {
            onClose();
          }
        }
      } catch (err: any) {
        addToast('error', 'Faylni o\'qishda xatolik', err.message);
      }
    };
    reader.readAsText(file);
    // Reset file input value
    e.target.value = '';
  };

  const handleReset = async () => {
    if (
      window.confirm(
        "Diqqat! Barcha o'quvchilar va sinflar boshlang'ich namunaviy holatga qaytarilsinmi?"
      )
    ) {
      setIsRestoring(true);
      await resetToDefault();
      setIsRestoring(false);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl rounded-3xl border border-white/60 dark:border-slate-800 shadow-2xl p-6 sm:p-7 text-slate-800 dark:text-slate-100 relative"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold tracking-tight">
              Baza Zaxira Nusxasi & Zero-Data-Loss
            </h3>
            <p className="text-xs text-slate-500">
              Ma'lumotlar bazasini 100% xavfsiz saqlash va tiklash markazi
            </p>
          </div>
        </div>

        {/* Protection Info */}
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-emerald-900 dark:text-emerald-200 text-xs mb-5 space-y-2">
          <div className="flex items-center gap-2 font-bold text-sm text-emerald-800 dark:text-emerald-300">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Dual-Layer Sync (Ikki bosqichli xavfsizlik):</span>
          </div>
          <p className="leading-relaxed opacity-90">
            1. <strong>Brauzer xotirasi (LocalStorage)</strong>: Har bir kiritilgan harf kompyuteringizda darhol saqlanadi. Internet uzilsa ham 1 ta o'quvchi yo'qolmaydi.
          </p>
          <p className="leading-relaxed opacity-90">
            2. <strong>Server atomik fayl bazasi</strong>: Barcha o'zgarishlar avtomatik JSON zaxira fayllariga yozib boriladi va bo'sh baza bilan tasodifiy o'chirish bloklanadi.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          {/* Export */}
          <button
            onClick={exportDatabaseJSON}
            className="w-full flex items-center justify-between p-4 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center">
                <Download className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-sm font-bold text-slate-900 dark:text-white">
                  Zaxira Nusxani Yuklab Olish (.json)
                </div>
                <div className="text-xs text-slate-500">
                  {data.classes.length} sinf, {data.students.length} o'quvchi, {data.teachers.length} ustoz
                </div>
              </div>
            </div>
            <FileJson className="w-5 h-5 text-slate-400 group-hover:text-blue-500 transition-colors" />
          </button>

          {/* Import */}
          <div className="relative">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-between p-4 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-600 flex items-center justify-center">
                  <Upload className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold text-slate-900 dark:text-white">
                    Zaxira Faylidan Qayta Tiklash
                  </div>
                  <div className="text-xs text-slate-500">
                    Oldin yuklab olingan .json faylni yuklash
                  </div>
                </div>
              </div>
              <FileJson className="w-5 h-5 text-slate-400 group-hover:text-indigo-500 transition-colors" />
            </button>
          </div>

          {/* Admin Reset to Default */}
          {isAdmin && (
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={handleReset}
                disabled={isRestoring}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/50 border border-rose-200 dark:border-rose-900 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Boshlang'ich Namunaviy Holatga Qaytarish (Reset)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
