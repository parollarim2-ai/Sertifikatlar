import React, { useState, useMemo } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { calculateFinanceMetrics, generateTelegramReport } from '../utils/logic';
import {
  CircleDollarSign,
  CheckCircle2,
  AlertCircle,
  Clock,
  Send,
  Edit3,
  TrendingUp,
  CreditCard,
  Building,
  Check,
} from 'lucide-react';

export const FinanceMatrix: React.FC = () => {
  const { data, markClassFullPaid, updateClassPayment, isAdmin, addToast } = useDatabase();

  const [editingClassId, setEditingClassId] = useState<string | null>(null);
  const [customAmount, setCustomAmount] = useState<string>('');

  // Overall School Financial Metrics
  const schoolMetrics = useMemo(() => {
    let totalStudents = data.students.length;
    let totalDue = 0;
    let totalPaid = 0;
    let fullyPaidClasses = 0;

    for (const cls of data.classes) {
      const clsStudents = data.students.filter((s) => s.classId === cls.id).length;
      const metrics = calculateFinanceMetrics({
        studentCount: clsStudents,
        pricePerStudent: cls.certificatePrice || 10000,
        paidAmount: cls.paidAmount || 0,
      });
      totalDue += metrics.totalDue;
      totalPaid += metrics.paidAmount;
      if (metrics.status === 'paid') {
        fullyPaidClasses += 1;
      }
    }

    const totalDebt = Math.max(0, totalDue - totalPaid);
    const collectionPercent = totalDue > 0 ? Math.min(100, Math.round((totalPaid / totalDue) * 100)) : 100;

    return {
      totalStudents,
      totalDue,
      totalPaid,
      totalDebt,
      fullyPaidClasses,
      totalClasses: data.classes.length,
      collectionPercent,
    };
  }, [data.classes, data.students]);

  const nf = new Intl.NumberFormat('uz-UZ');

  const handleOpenEditPayment = (classId: string, currentPaid: number) => {
    setEditingClassId(classId);
    setCustomAmount(String(currentPaid));
  };

  const handleSaveCustomPayment = (classId: string) => {
    const parsed = parseInt(customAmount, 10);
    if (isNaN(parsed) || parsed < 0) {
      addToast('warning', 'To\'g\'ri summa kiriting');
      return;
    }
    updateClassPayment(classId, parsed);
    setEditingClassId(null);
  };

  const handleCopyTelegramFinanceReport = () => {
    const certifiedCount = data.students.filter((s) => s.status === 'certified').length;
    const pendingCount = data.students.filter((s) => s.status === 'pending').length;
    const errorCount = data.students.filter((s) => s.status === 'error').length;

    const report = generateTelegramReport({
      scopeName: "Maktab Ta'lim Portali Moliya",
      totalStudents: schoolMetrics.totalStudents,
      certifiedCount,
      pendingCount,
      errorCount,
      totalPrice: schoolMetrics.totalDue,
      paidAmount: schoolMetrics.totalPaid,
      debtAmount: schoolMetrics.totalDebt,
    });

    navigator.clipboard.writeText(report).then(() => {
      addToast('success', 'Moliya hisoboti nusxalandi! 📋', 'Telegramga tashlash uchun tayyor');
    }).catch(() => {
      window.prompt("Hisobot matnini nusxalang:", report);
    });
  };

  return (
    <div className="w-full space-y-6">
      {/* Top Banner KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Due */}
        <div className="p-5 rounded-3xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Jami Hisoblangan</span>
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              {nf.format(schoolMetrics.totalDue)} <span className="text-xs font-normal text-slate-400">so'm</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              {schoolMetrics.totalStudents} ta o'quvchi x 10 000 so'm
            </p>
          </div>
        </div>

        {/* Collected Paid */}
        <div className="p-5 rounded-3xl bg-emerald-500/5 dark:bg-emerald-950/20 backdrop-blur-2xl border border-emerald-500/20 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">To'langan Summa</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-emerald-700 dark:text-emerald-300 tracking-tight">
              {nf.format(schoolMetrics.totalPaid)} <span className="text-xs font-normal opacity-70">so'm</span>
            </h3>
            <div className="flex items-center gap-2 mt-1">
              <div className="flex-1 h-1.5 rounded-full bg-emerald-200 dark:bg-emerald-900 overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                  style={{ width: `${schoolMetrics.collectionPercent}%` }}
                />
              </div>
              <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">
                {schoolMetrics.collectionPercent}%
              </span>
            </div>
          </div>
        </div>

        {/* Remaining Debt */}
        <div className="p-5 rounded-3xl bg-rose-500/5 dark:bg-rose-950/20 backdrop-blur-2xl border border-rose-500/20 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-rose-700 dark:text-rose-300">Qolgan Qarzdorlik</span>
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-600 flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-rose-700 dark:text-rose-300 tracking-tight">
              {nf.format(schoolMetrics.totalDebt)} <span className="text-xs font-normal opacity-70">so'm</span>
            </h3>
            <p className="text-xs text-rose-600/80 dark:text-rose-400/80 mt-1">
              {schoolMetrics.totalDebt === 0 ? "Barcha to'lovlar yakunlangan ✓" : "Yig'ilishi kerak bo'lgan mablag'"}
            </p>
          </div>
        </div>

        {/* Classes completion */}
        <div className="p-5 rounded-3xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-xs relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Sinflar Holati</span>
            <button
              onClick={handleCopyTelegramFinanceReport}
              className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold bg-sky-50 text-sky-700 border border-sky-200 dark:bg-sky-950 dark:text-sky-300 transition-colors"
              title="Moliya hisobotini nusxalash"
            >
              <Send className="w-3 h-3 text-sky-500" />
              <span>Hisobot</span>
            </button>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              {schoolMetrics.fullyPaidClasses} / {schoolMetrics.totalClasses}
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              sinflar to'lovni to'liq amalga oshirdi
            </p>
          </div>
        </div>
      </div>

      {/* Class by Class Payment Breakdown Table */}
      <div className="overflow-hidden rounded-3xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-md">
        <div className="p-4 sm:p-5 border-b border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Sinflar Bo'yicha To'lovlar Matritsasi
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Har bir sinf o'quvchilari soni, to'langan va qarzdorlik summalarining aniq balansi
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200/80 dark:border-slate-800/80 bg-slate-50/60 dark:bg-slate-800/40 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                <th className="py-3.5 px-4">Sinf nomi</th>
                <th className="py-3.5 px-4">Sinf Rahbari</th>
                <th className="py-3.5 px-4 text-center">O'quvchilar</th>
                <th className="py-3.5 px-4 text-right">Hisoblangan</th>
                <th className="py-3.5 px-4 text-right">To'langan</th>
                <th className="py-3.5 px-4 text-right">Qarzdorlik</th>
                <th className="py-3.5 px-4 text-center">To'lov Holati</th>
                <th className="py-3.5 px-4 text-right">Amal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {data.classes.map((cls) => {
                const clsStudents = data.students.filter((s) => s.classId === cls.id);
                const count = clsStudents.length;
                const metrics = calculateFinanceMetrics({
                  studentCount: count,
                  pricePerStudent: cls.certificatePrice || 10000,
                  paidAmount: cls.paidAmount || 0,
                });

                const isEditing = editingClassId === cls.id;

                return (
                  <tr key={cls.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-base text-blue-600 dark:text-blue-400">
                        {cls.name}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 font-medium">
                      {cls.teacherName || '—'}
                    </td>

                    <td className="py-3.5 px-4 text-center font-mono font-semibold">
                      {count} nafar
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-800 dark:text-slate-200">
                      {nf.format(metrics.totalDue)} so'm
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {isEditing ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <input
                            type="number"
                            value={customAmount}
                            onChange={(e) => setCustomAmount(e.target.value)}
                            className="w-24 px-2 py-1 text-xs border rounded-lg bg-white dark:bg-slate-900 border-blue-500 font-mono text-right"
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveCustomPayment(cls.id)}
                            className="p-1 rounded-md bg-emerald-600 text-white"
                            title="Saqlash"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span>{nf.format(metrics.paidAmount)} so'm</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-rose-600 dark:text-rose-400">
                      {metrics.debt > 0 ? `${nf.format(metrics.debt)} so'm` : '0 so\'m'}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      {metrics.status === 'paid' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>To'liq to'landi</span>
                        </span>
                      )}
                      {metrics.status === 'partial' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>Qisman to'landi</span>
                        </span>
                      )}
                      {metrics.status === 'unpaid' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">
                          <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                          <span>To'lanmagan</span>
                        </span>
                      )}
                    </td>

                    {/* Quick payment action buttons */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {metrics.status !== 'paid' && (
                          <button
                            onClick={() => markClassFullPaid(cls.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950/60 dark:hover:bg-emerald-900 dark:text-emerald-300 border border-emerald-300 transition-all active:scale-95"
                            title="Bir bosishda to'liq to'langan deb tasdiqlash"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>[✓ To'liq]</span>
                          </button>
                        )}

                        <button
                          onClick={() => handleOpenEditPayment(cls.id, cls.paidAmount || 0)}
                          className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          title="Summani tahrirlash"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
