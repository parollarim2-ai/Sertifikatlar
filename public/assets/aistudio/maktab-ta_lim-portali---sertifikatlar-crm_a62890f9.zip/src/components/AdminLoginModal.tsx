import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { ShieldCheck, Lock, AlertOctagon, KeyRound, X, ArrowRight } from 'lucide-react';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({ isOpen, onClose }) => {
  const { loginAsAdmin, adminLoginError, adminRemainingAttempts, adminLockedUntil } = useDatabase();
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);

  // Handle countdown if locked
  useEffect(() => {
    if (!adminLockedUntil) {
      setCountdown(null);
      return;
    }

    const updateRemaining = () => {
      const remainingSecs = Math.max(0, Math.ceil((adminLockedUntil - Date.now()) / 1000));
      setCountdown(remainingSecs);
    };

    updateRemaining();
    const interval = setInterval(updateRemaining, 1000);
    return () => clearInterval(interval);
  }, [adminLockedUntil]);

  // ESC key handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim() || isSubmitting) return;

    setIsSubmitting(true);
    const success = await loginAsAdmin(password);
    setIsSubmitting(false);

    if (success) {
      setPassword('');
      onClose();
    }
  };

  const isLocked = Boolean(countdown && countdown > 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-white/90 dark:bg-slate-900/95 backdrop-blur-2xl rounded-3xl border border-white/60 dark:border-slate-800 shadow-2xl p-6 sm:p-8 text-slate-800 dark:text-slate-100 relative"
        role="dialog"
        aria-modal="true"
        aria-labelledby="admin-dialog-title"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Yopish"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/25 mb-4 text-white">
            <ShieldCheck className="w-9 h-9" />
          </div>
          <h2 id="admin-dialog-title" className="text-xl font-bold tracking-tight">
            Administrator Boshqaruv Rejimi
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1.5 max-w-xs">
            Maktab o'quvchilari va sinflarni to'liq boshqarish uchun maxfiy parolni kiriting
          </p>
        </div>

        {isLocked ? (
          <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-rose-700 dark:text-rose-300 mb-5 flex items-start gap-3">
            <AlertOctagon className="w-5 h-5 shrink-0 mt-0.5" />
            <div className="text-xs">
              <p className="font-semibold text-sm">Xavfsizlik blokirovkasi yoqilgan!</p>
              <p className="mt-1">
                Ketma-ket 5 ta noto'g'ri urinish tufayli tizim vaqtincha bloklandi.
              </p>
              <p className="mt-2 font-mono font-bold text-rose-800 dark:text-rose-200">
                Qolgan vaqt: {Math.floor((countdown || 0) / 60)} daqiqa {(countdown || 0) % 60} soniya
              </p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="admin-password"
                className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-2"
              >
                Maxfiy Administrator Kodi
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <KeyRound className="w-5 h-5" />
                </div>
                <input
                  id="admin-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Maxfiy parolni kiriting..."
                  autoFocus
                  required
                  disabled={isSubmitting || isLocked}
                  className="w-full pl-11 pr-4 py-3 bg-slate-100/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm font-medium"
                />
              </div>
            </div>

            {adminLoginError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs">
                <p className="font-semibold">{adminLoginError}</p>
                {adminRemainingAttempts !== null && adminRemainingAttempts > 0 && (
                  <p className="mt-0.5 text-rose-600 dark:text-rose-400">
                    Qolgan urinishlar: {adminRemainingAttempts} ta (5 tadan so'ng 15 daqiqaga bloklanadi)
                  </p>
                )}
              </div>
            )}

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting || !password.trim() || isLocked}
                className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl font-semibold text-sm text-white bg-blue-600 hover:bg-blue-700 active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none shadow-lg shadow-blue-600/25 transition-all"
              >
                {isSubmitting ? (
                  <span>Tekshirilmoqda...</span>
                ) : (
                  <>
                    <span>Admin Rejimiga Kirish</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        <div className="mt-6 pt-5 border-t border-slate-200/60 dark:border-slate-800 text-center">
          <div className="inline-flex items-center gap-1.5 text-xs text-slate-400">
            <Lock className="w-3.5 h-3.5" />
            <span>HMAC-SHA256 shifrlangan 24 soatlik xavfsiz sessiya</span>
          </div>
        </div>
      </div>
    </div>
  );
};
