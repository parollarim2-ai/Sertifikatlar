import React, { useState, useMemo } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { TeacherCertificate } from '../types';
import { extractPassport7Digits, formatFullPassport, normalizeDate } from '../utils/logic';
import {
  Award,
  Search,
  ArrowUpDown,
  FileSpreadsheet,
  Plus,
  CheckCircle2,
  Clock,
  AlertCircle,
  ExternalLink,
  ClipboardPaste,
  ClipboardCopy,
  Edit2,
  Trash2,
  Mail,
  Phone,
  BookOpen,
  X,
} from 'lucide-react';

export const TeacherCertificates: React.FC = () => {
  const {
    data,
    addTeacher,
    updateTeacher,
    deleteTeacher,
    attachTeacherCertificate,
    isAdmin,
    addToast,
  } = useDatabase();

  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'subject' | 'status' | 'debt'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<TeacherCertificate | null>(null);

  // Form states
  const [fullName, setFullName] = useState('');
  const [subject, setSubject] = useState('');
  const [passport, setPassport] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [certificateUrl, setCertificateUrl] = useState('');
  const [status, setStatus] = useState<'pending' | 'certified' | 'error'>('pending');
  const [paidAmount, setPaidAmount] = useState<number>(10000);
  const [notes, setNotes] = useState('');

  const nf = new Intl.NumberFormat('uz-UZ');

  const openAddModal = () => {
    setEditingTeacher(null);
    setFullName('');
    setSubject('');
    setPassport('');
    setBirthDate('');
    setEmailOrPhone('');
    setCertificateUrl('');
    setStatus('pending');
    setPaidAmount(10000);
    setNotes('');
    setIsModalOpen(true);
  };

  const openEditModal = (teacher: TeacherCertificate) => {
    setEditingTeacher(teacher);
    setFullName(teacher.fullName);
    setSubject(teacher.subject);
    setPassport(teacher.passport);
    setBirthDate(teacher.birthDate || '');
    setEmailOrPhone(teacher.emailOrPhone);
    setCertificateUrl(teacher.certificateUrl || '');
    setStatus(teacher.status);
    setPaidAmount(teacher.paidAmount);
    setNotes(teacher.notes || '');
    setIsModalOpen(true);
  };

  const handleSaveTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !subject.trim()) {
      addToast('warning', 'Ustoz F.I.SH va fani kiritilishi shart');
      return;
    }

    const payload = {
      fullName: fullName.trim(),
      subject: subject.trim(),
      passport: formatFullPassport(passport) || 'KIRITILMAGAN',
      birthDate: normalizeDate(birthDate),
      emailOrPhone: emailOrPhone.trim(),
      certificateUrl: certificateUrl.trim() || undefined,
      certifiedAt: status === 'certified' ? (editingTeacher?.certifiedAt || new Date().toISOString()) : undefined,
      status,
      price: 10000,
      paidAmount: Number(paidAmount) || 0,
      notes: notes.trim() || undefined,
    };

    if (editingTeacher) {
      updateTeacher(editingTeacher.id, payload);
    } else {
      addTeacher(payload);
    }

    setIsModalOpen(false);
  };

  // 1-Click Paste Certificate
  const handlePasteCertificate = async (e: React.MouseEvent, teacherId: string) => {
    e.stopPropagation();
    try {
      let clipboardText = '';
      if (navigator.clipboard && navigator.clipboard.readText) {
        try {
          clipboardText = await navigator.clipboard.readText();
        } catch {}
      }

      if (!clipboardText || !clipboardText.trim()) {
        const input = window.prompt("Ustoz sertifikati havolasini (URL) kiriting:");
        if (!input) return;
        clipboardText = input;
      }

      if (clipboardText.trim()) {
        attachTeacherCertificate(teacherId, clipboardText.trim());
      }
    } catch (err: any) {
      addToast('error', 'Xatolik', err.message);
    }
  };

  // 1-Click Copy 7 digits
  const handleCopy7Digits = (e: React.MouseEvent, pass: string) => {
    e.stopPropagation();
    const digits = extractPassport7Digits(pass);
    if (!digits) return;
    navigator.clipboard.writeText(digits).then(() => {
      addToast('success', `7 xonali raqam nusxalandi: ${digits}`);
    });
  };

  // Filter & Sort
  const processedTeachers = useMemo(() => {
    let list = data.teachers.filter((t) => {
      const q = searchQuery.toLowerCase();
      return (
        t.fullName.toLowerCase().includes(q) ||
        t.subject.toLowerCase().includes(q) ||
        t.passport.toLowerCase().includes(q)
      );
    });

    list.sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'name') {
        comparison = a.fullName.localeCompare(b.fullName, 'uz');
      } else if (sortBy === 'subject') {
        comparison = a.subject.localeCompare(b.subject, 'uz');
      } else if (sortBy === 'status') {
        comparison = a.status.localeCompare(b.status);
      } else if (sortBy === 'debt') {
        const debtA = Math.max(0, (a.price || 10000) - a.paidAmount);
        const debtB = Math.max(0, (b.price || 10000) - b.paidAmount);
        comparison = debtB - debtA;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return list;
  }, [data.teachers, searchQuery, sortBy, sortOrder]);

  // Export Teachers to Excel (CSV UTF-8 BOM)
  const handleExportTeachersExcel = () => {
    if (!data.teachers.length) {
      addToast('warning', 'Eksport qilish uchun ustozlar mavjud emas');
      return;
    }

    const headers = ['№', 'F.I.SH', 'Fani', 'Pasport', 'Tug\'ilgan sana', 'Telefon/Aloqa', 'Holat', 'Sertifikat URL', 'To\'langan summa', 'Qarz'];
    const rows = processedTeachers.map((t, idx) => {
      const debt = Math.max(0, (t.price || 10000) - t.paidAmount);
      return [
        idx + 1,
        `"${t.fullName.replace(/"/g, '""')}"`,
        `"${t.subject.replace(/"/g, '""')}"`,
        `"${t.passport}"`,
        `"${t.birthDate || ''}"`,
        `"${t.emailOrPhone || ''}"`,
        t.status === 'certified' ? 'Tayyor' : 'Kutilmoqda',
        `"${t.certificateUrl || ''}"`,
        t.paidAmount,
        debt,
      ];
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ustozlar_sertifikatlar_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    addToast('success', 'Ustozlar ro\'yxati Excel (CSV) fayliga yuklab olindi');
  };

  const totalCertified = data.teachers.filter((t) => t.status === 'certified').length;

  return (
    <div className="w-full space-y-6">
      {/* Teacher Section Purple Theme Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-purple-900/10 via-purple-600/10 to-indigo-600/10 dark:from-purple-950/40 dark:to-indigo-950/40 backdrop-blur-2xl border border-purple-200/80 dark:border-purple-800/60 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-purple-600 flex items-center justify-center text-white shadow-lg shadow-purple-600/25 shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">
                Ustozlar va Pedagoglar Sertifikatlari
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                {totalCertified}/{data.teachers.length} tayyor
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Maktab o'qituvchilarining toifa, attestatsiya va milliy sertifikatlar hisobi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportTeachersExcel}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-semibold text-purple-800 dark:text-purple-200 bg-white dark:bg-slate-800 hover:bg-purple-50 dark:hover:bg-slate-700 border border-purple-200 dark:border-purple-800/60 shadow-xs transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-purple-600" />
            <span>Ustozlar Excel</span>
          </button>

          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 active:scale-95 shadow-md shadow-purple-600/25 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Ustoz Qo'shish</span>
          </button>
        </div>
      </div>

      {/* Filter and Sort Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 rounded-3xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Ustoz ismi, fani yoki pasporti bo'yicha qidirish..."
            className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 font-medium"
          />
        </div>

        {/* Sort Controls */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium hidden sm:inline">Saralash:</span>
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
            <button
              onClick={() => {
                if (sortBy === 'name') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                else { setSortBy('name'); setSortOrder('asc'); }
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                sortBy === 'name' ? 'bg-white dark:bg-slate-900 text-purple-700 dark:text-purple-300 shadow-xs' : 'text-slate-500'
              }`}
            >
              <span>A-Z Ism</span>
              {sortBy === 'name' && <ArrowUpDown className="w-3 h-3" />}
            </button>

            <button
              onClick={() => {
                if (sortBy === 'subject') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                else { setSortBy('subject'); setSortOrder('asc'); }
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                sortBy === 'subject' ? 'bg-white dark:bg-slate-900 text-purple-700 dark:text-purple-300 shadow-xs' : 'text-slate-500'
              }`}
            >
              <span>Fan</span>
              {sortBy === 'subject' && <ArrowUpDown className="w-3 h-3" />}
            </button>

            <button
              onClick={() => {
                if (sortBy === 'debt') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                else { setSortBy('debt'); setSortOrder('asc'); }
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                sortBy === 'debt' ? 'bg-white dark:bg-slate-900 text-purple-700 dark:text-purple-300 shadow-xs' : 'text-slate-500'
              }`}
            >
              <span>Qarz</span>
              {sortBy === 'debt' && <ArrowUpDown className="w-3 h-3" />}
            </button>
          </div>
        </div>
      </div>

      {/* Teachers Table */}
      <div className="overflow-hidden rounded-3xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200/80 dark:border-slate-800/80 bg-slate-50/60 dark:bg-slate-800/40 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                <th className="py-3.5 px-4 w-12 text-center">№</th>
                <th className="py-3.5 px-4 min-w-[200px]">Ustoz F.I.SH</th>
                <th className="py-3.5 px-4 min-w-[150px]">Fani</th>
                <th className="py-3.5 px-4 min-w-[130px]">Pasport</th>
                <th className="py-3.5 px-4 min-w-[140px]">Aloqa</th>
                <th className="py-3.5 px-4 min-w-[130px]">Holat</th>
                <th className="py-3.5 px-4 min-w-[180px]">Sertifikat havolasi</th>
                <th className="py-3.5 px-4 text-right">To'lov & Qarz</th>
                <th className="py-3.5 px-4 w-24 text-right">Amal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {processedTeachers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    Ustozlar ro'yxati bo'sh. "+ Ustoz Qo'shish" tugmasini bosing
                  </td>
                </tr>
              ) : (
                processedTeachers.map((teacher, idx) => {
                  const isCertified = teacher.status === 'certified';
                  const debt = Math.max(0, (teacher.price || 10000) - teacher.paidAmount);

                  return (
                    <tr
                      key={teacher.id}
                      onClick={() => openEditModal(teacher)}
                      className="hover:bg-purple-50/40 dark:hover:bg-purple-950/20 transition-colors cursor-pointer group"
                    >
                      <td className="py-3.5 px-4 text-center font-mono text-xs text-slate-400">
                        {idx + 1}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                          {teacher.fullName}
                        </div>
                        {teacher.notes && (
                          <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                            {teacher.notes}
                          </p>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200/60 dark:border-purple-800/60">
                          <BookOpen className="w-3 h-3" />
                          <span>{teacher.subject}</span>
                        </span>
                      </td>

                      <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={(e) => handleCopy7Digits(e, teacher.passport)}
                          className="font-mono text-xs font-bold px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-purple-100 text-slate-800 dark:text-slate-200 transition-colors"
                          title="7 xonali raqamni nusxalash"
                        >
                          {teacher.passport}
                        </button>
                      </td>

                      <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-300">
                        {teacher.emailOrPhone || '—'}
                      </td>

                      <td className="py-3.5 px-4">
                        {isCertified ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Tayyor</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                            <Clock className="w-3 h-3 text-amber-600" />
                            <span>Kutilmoqda</span>
                          </span>
                        )}
                      </td>

                      {/* Certificate link / Paste button */}
                      <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                        {teacher.certificateUrl ? (
                          <a
                            href={teacher.certificateUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 transition-colors"
                          >
                            <span>Ko'rish</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        ) : (
                          <button
                            onClick={(e) => handlePasteCertificate(e, teacher.id)}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 transition-all active:scale-95"
                          >
                            <ClipboardPaste className="w-3.5 h-3.5 text-emerald-600" />
                            <span>[📋 Qo'yish]</span>
                          </button>
                        )}
                      </td>

                      {/* Debt & Paid */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="font-mono text-xs font-bold text-slate-800 dark:text-slate-200">
                          {nf.format(teacher.paidAmount)} so'm
                        </div>
                        {debt > 0 ? (
                          <div className="text-[10px] text-rose-600 dark:text-rose-400 font-bold">
                            Qarz: {nf.format(debt)} so'm
                          </div>
                        ) : (
                          <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                            To'liq to'langan ✓
                          </div>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openEditModal(teacher)}
                            className="p-1.5 rounded-xl text-slate-500 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-slate-800 transition-colors"
                            title="Tahrirlash"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          {isAdmin && (
                            <button
                              onClick={() => {
                                if (window.confirm(`${teacher.fullName} o'chirilsinmi?`)) {
                                  deleteTeacher(teacher.id);
                                }
                              }}
                              className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800 transition-colors"
                              title="O'chirish"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Teacher Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="w-full max-w-lg bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl rounded-3xl border border-white/60 dark:border-slate-800 shadow-2xl p-6 sm:p-7 text-slate-800 dark:text-slate-100 relative max-h-[90vh] overflow-y-auto"
            role="dialog"
            aria-modal="true"
          >
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-600 dark:text-purple-400">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold tracking-tight">
                  {editingTeacher ? 'Ustoz Sertifikatini Tahrirlash' : 'Yangi Ustoz Sertifikati'}
                </h3>
                <p className="text-xs text-slate-500">
                  Pedagog toifasi va sertifikat ma'lumotlarini kiritish
                </p>
              </div>
            </div>

            <form onSubmit={handleSaveTeacher} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
                  Ustoz F.I.SH:
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Qodirova Nilufar Rustamovna"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm font-semibold outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
                  Dars Beradigan Fani:
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Matematika va Algebra / Ingliz tili"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm font-semibold outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
                    Pasport:
                  </label>
                  <input
                    type="text"
                    value={passport}
                    onChange={(e) => setPassport(e.target.value.toUpperCase())}
                    placeholder="AA1122334"
                    className="w-full px-3.5 py-2.5 font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
                    Telefon / Aloqa:
                  </label>
                  <input
                    type="text"
                    value={emailOrPhone}
                    onChange={(e) => setEmailOrPhone(e.target.value)}
                    placeholder="+998 90 123 45 67"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
                  Sertifikat Holati:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setStatus('certified')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors ${
                      status === 'certified' ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    Tayyor (✓)
                  </button>
                  <button
                    type="button"
                    onClick={() => setStatus('pending')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors ${
                      status === 'pending' ? 'bg-amber-500 text-white border-amber-500' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    Kutilmoqda (⏳)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
                  Sertifikat Havolasi (URL):
                </label>
                <input
                  type="url"
                  value={certificateUrl}
                  onChange={(e) => setCertificateUrl(e.target.value)}
                  placeholder="https://cert.maktab.uz/verify/TCH-..."
                  className="w-full px-3.5 py-2.5 font-mono text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
                    To'langan Summa (so'm):
                  </label>
                  <input
                    type="number"
                    value={paidAmount}
                    onChange={(e) => setPaidAmount(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
                    Qo'shimcha izoh:
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Oliy toifali ustoz, IELTS 8.0"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 shadow-md shadow-purple-600/25"
                >
                  Saqlash
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
