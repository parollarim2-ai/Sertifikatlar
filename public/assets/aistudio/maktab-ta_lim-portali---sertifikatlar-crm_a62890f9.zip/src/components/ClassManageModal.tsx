import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { ClassGroup } from '../types';
import { Layers, X, Trash2, UserCheck, Phone, DollarSign } from 'lucide-react';

interface ClassManageModalProps {
  isOpen: boolean;
  classToEdit: ClassGroup | null; // null means create new class
  onClose: () => void;
}

export const ClassManageModal: React.FC<ClassManageModalProps> = ({
  isOpen,
  classToEdit,
  onClose,
}) => {
  const { addClass, updateClass, deleteClass, addToast } = useDatabase();

  const [name, setName] = useState('');
  const [teacherName, setTeacherName] = useState('');
  const [teacherPhone, setTeacherPhone] = useState('');
  const [certificatePrice, setCertificatePrice] = useState<number>(10000);

  useEffect(() => {
    if (classToEdit) {
      setName(classToEdit.name);
      setTeacherName(classToEdit.teacherName || '');
      setTeacherPhone(classToEdit.teacherPhone || '');
      setCertificatePrice(classToEdit.certificatePrice || 10000);
    } else {
      setName('');
      setTeacherName('');
      setTeacherPhone('');
      setCertificatePrice(10000);
    }
  }, [classToEdit, isOpen]);

  // ESC to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      addToast('warning', 'Sinf nomi kiritilishi shart (masalan: 10-A)');
      return;
    }

    const payload = {
      name: name.trim().toUpperCase(),
      teacherName: teacherName.trim(),
      teacherPhone: teacherPhone.trim(),
      certificatePrice: Number(certificatePrice) || 10000,
      paidAmount: classToEdit?.paidAmount || 0,
    };

    if (classToEdit) {
      updateClass(classToEdit.id, payload);
    } else {
      addClass(payload);
    }

    onClose();
  };

  const handleDelete = () => {
    if (!classToEdit) return;
    if (
      window.confirm(
        `Diqqat! "${classToEdit.name}" sinfini va unga tegishli barcha o'quvchilarni o'chirishni tasdiqlaysizmi?`
      )
    ) {
      deleteClass(classToEdit.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl rounded-3xl border border-white/60 dark:border-slate-800 shadow-2xl p-6 sm:p-7 text-slate-800 dark:text-slate-100 relative"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-600 dark:text-blue-400">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold tracking-tight">
              {classToEdit ? `${classToEdit.name} Sinfini Tahrirlash` : 'Yangi Sinf Qo\'shish'}
            </h3>
            <p className="text-xs text-slate-500">
              Sinf nomi va sinf rahbari ma'lumotlari
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300">
              Sinf Nomi:
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masalan: 10-A, 8-B, 11-V"
              required
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-base font-bold outline-none focus:ring-2 focus:ring-blue-500 uppercase"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300 flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5" />
              <span>Sinf Rahbari F.I.SH:</span>
            </label>
            <input
              type="text"
              value={teacherName}
              onChange={(e) => setTeacherName(e.target.value)}
              placeholder="Qodirova Nilufar Rustamovna"
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300 flex items-center gap-1">
              <Phone className="w-3.5 h-3.5" />
              <span>Sinf Rahbari Telefoni:</span>
            </label>
            <input
              type="text"
              value={teacherPhone}
              onChange={(e) => setTeacherPhone(e.target.value)}
              placeholder="+998 90 123 45 67"
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-slate-300 flex items-center gap-1">
              <DollarSign className="w-3.5 h-3.5" />
              <span>Sertifikat Narxi (O'quvchi boshiga, so'm):</span>
            </label>
            <input
              type="number"
              value={certificatePrice}
              onChange={(e) => setCertificatePrice(Number(e.target.value))}
              placeholder="10000"
              className="w-full px-3.5 py-2.5 font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
            {classToEdit ? (
              <button
                type="button"
                onClick={handleDelete}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Sinfni O'chirish</span>
              </button>
            ) : (
              <span />
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-500"
              >
                Bekor qilish
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-2xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-600/25"
              >
                Saqlash
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
