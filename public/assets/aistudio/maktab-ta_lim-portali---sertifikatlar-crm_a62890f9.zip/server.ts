import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Secret key for HMAC token signing and verification
const SECRET_KEY = process.env.ADMIN_SECRET_KEY || 'maktab_portal_secret_salt_2026_crm_secure_key';
// Admin password hash generated on server
const ADMIN_PASSWORD_PLAIN = 'AistudyMaktab@2026#SecureAdmin';
const ADMIN_PASSWORD_HASH = crypto.createHmac('sha256', SECRET_KEY).update(ADMIN_PASSWORD_PLAIN).digest('hex');

// Rate limiting state for admin login: 5 attempts -> 15 min lock
interface RateLimitRecord {
  attempts: number;
  lockedUntil: number;
}
const loginRateLimitMap = new Map<string, RateLimitRecord>();

function getClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

function generateAdminToken(): { token: string; expiresAt: number } {
  const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
  const payload = JSON.stringify({ role: 'admin', expiresAt, nonce: crypto.randomBytes(8).toString('hex') });
  const payloadB64 = Buffer.from(payload).toString('base64url');
  const signature = crypto.createHmac('sha256', SECRET_KEY).update(payloadB64).digest('base64url');
  return { token: `${payloadB64}.${signature}`, expiresAt };
}

function verifyAdminToken(token?: string): boolean {
  if (!token) return false;
  const parts = token.split('.');
  if (parts.length !== 2) return false;
  const [payloadB64, signature] = parts;
  const expectedSignature = crypto.createHmac('sha256', SECRET_KEY).update(payloadB64).digest('base64url');
  if (signature !== expectedSignature) return false;

  try {
    const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8'));
    if (payload.role !== 'admin') return false;
    if (typeof payload.expiresAt !== 'number' || Date.now() > payload.expiresAt) return false;
    return true;
  } catch {
    return false;
  }
}

// Database file setup
const DATA_DIR = path.join(__dirname, 'data');
const BACKUPS_DIR = path.join(DATA_DIR, 'backups');
const DB_FILE = path.join(DATA_DIR, 'school_database.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(BACKUPS_DIR)) {
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
}

// Initial realistic default data (100% clean, independent, realistic)
function getInitialData() {
  const classes = [
    {
      id: 'cls-5a',
      name: '5-A',
      teacherName: 'Qodirova Nilufar Rustamovna',
      teacherPhone: '+998 90 123 45 67',
      certificatePrice: 10000,
      paidAmount: 80000,
    },
    {
      id: 'cls-6b',
      name: '6-B',
      teacherName: 'Xalilov Bobur Shavkatovich',
      teacherPhone: '+998 91 234 56 78',
      certificatePrice: 10000,
      paidAmount: 70000,
    },
    {
      id: 'cls-7a',
      name: '7-A',
      teacherName: 'Rahimova Dilnoza Alisherovna',
      teacherPhone: '+998 93 345 67 89',
      certificatePrice: 10000,
      paidAmount: 60000,
    },
    {
      id: 'cls-8v',
      name: '8-V',
      teacherName: 'Toirov Jasur Bahromovich',
      teacherPhone: '+998 94 456 78 90',
      certificatePrice: 10000,
      paidAmount: 100000,
    },
    {
      id: 'cls-9d',
      name: '9-D',
      teacherName: 'Mirzayeva Shahnoza Akramovna',
      teacherPhone: '+998 97 567 89 01',
      certificatePrice: 10000,
      paidAmount: 40000,
    },
    {
      id: 'cls-11a',
      name: '11-A',
      teacherName: 'Soliyev Farrux Odilovich',
      teacherPhone: '+998 99 678 90 12',
      certificatePrice: 10000,
      paidAmount: 90000,
    },
  ];

  const students = [
    // 5-A students
    {
      id: 'std-5a-1',
      classId: 'cls-5a',
      fullName: 'Abdullayev Sardor Jasur o\'g\'li',
      passport: 'AA1289456',
      birthDate: '14.03.2013',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/5A-001',
      certifiedAt: '2026-11-04T10:15:32.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-5a-2',
      classId: 'cls-5a',
      fullName: 'Bozorova Madinabonu Ilhom qizi',
      passport: 'AB3456789',
      birthDate: '22.07.2013',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/5A-002',
      certifiedAt: '2026-11-04T11:42:10.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-5a-3',
      classId: 'cls-5a',
      fullName: 'Ergashev Muhammadali Shavkat o\'g\'li',
      passport: 'AC9876543',
      birthDate: '05.11.2013',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-5a-4',
      classId: 'cls-5a',
      fullName: 'G\'aniyeva Rayhona Davron qizi',
      passport: 'AA7711223',
      birthDate: '19.01.2013',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-5a-5',
      classId: 'cls-5a',
      fullName: 'Husanov Azizbek Zafarovich',
      passport: 'I-TO 4567890',
      birthDate: '30.09.2013',
      status: 'error',
      errorReason: 'Metrika seriyasida raqam xato kiritilgan (baza bilan mos kelmadi)',
      paidAmount: 0,
    },
    {
      id: 'std-5a-6',
      classId: 'cls-5a',
      fullName: 'Ismoilov Diyorbek Jamshid o\'g\'li',
      passport: 'AB2233445',
      birthDate: '11.05.2013',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-5a-7',
      classId: 'cls-5a',
      fullName: 'Karimova Zilola Otabek qizi',
      passport: 'AA9988776',
      birthDate: '08.12.2013',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/5A-007',
      certifiedAt: '2026-11-04T14:20:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-5a-8',
      classId: 'cls-5a',
      fullName: 'Nazarov Shohruh Nodirovich',
      passport: 'AC5544332',
      birthDate: '17.02.2013',
      status: 'pending',
      paidAmount: 10000,
    },

    // 6-B students
    {
      id: 'std-6b-1',
      classId: 'cls-6b',
      fullName: 'Olimov Javohir Sherzod o\'g\'li',
      passport: 'AA8844221',
      birthDate: '03.04.2012',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/6B-101',
      certifiedAt: '2026-11-03T16:05:44.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-6b-2',
      classId: 'cls-6b',
      fullName: 'Po\'latova Sevinch Baxtiyor qizi',
      passport: 'AB6655443',
      birthDate: '25.08.2012',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/6B-102',
      certifiedAt: '2026-11-03T16:18:12.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-6b-3',
      classId: 'cls-6b',
      fullName: 'Rustamov Boburmirzo Mirjalol o\'g\'li',
      passport: 'AC1133557',
      birthDate: '12.10.2012',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-6b-4',
      classId: 'cls-6b',
      fullName: 'Sodiqova Mohinur Sanjar qizi',
      passport: 'AA3355779',
      birthDate: '01.06.2012',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/6B-104',
      certifiedAt: '2026-11-04T09:12:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-6b-5',
      classId: 'cls-6b',
      fullName: 'Tursunov Behruz Ulug\'bek o\'g\'li',
      passport: 'AB9911224',
      birthDate: '18.12.2012',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-6b-6',
      classId: 'cls-6b',
      fullName: 'Umarova Diyora Faxriddin qizi',
      passport: 'AC4422668',
      birthDate: '29.09.2012',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-6b-7',
      classId: 'cls-6b',
      fullName: 'Yusupov Biloliddin Ravshan o\'g\'li',
      passport: 'AA1144770',
      birthDate: '07.03.2012',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/6B-107',
      certifiedAt: '2026-11-04T09:45:00.000Z',
      paidAmount: 10000,
    },

    // 7-A students
    {
      id: 'std-7a-1',
      classId: 'cls-7a',
      fullName: 'Akbarov Timur Mansurovich',
      passport: 'AA4477881',
      birthDate: '16.02.2011',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/7A-201',
      certifiedAt: '2026-11-02T13:10:15.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-7a-2',
      classId: 'cls-7a',
      fullName: 'Bekmurodova Sabina Anvar qizi',
      passport: 'AB5588992',
      birthDate: '21.06.2011',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-7a-3',
      classId: 'cls-7a',
      fullName: 'Jo\'rayev Kamronbek Tohirovich',
      passport: 'AC6699003',
      birthDate: '09.11.2011',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-7a-4',
      classId: 'cls-7a',
      fullName: 'Qosimova Parizoda Dilshod qizi',
      passport: 'AA7700114',
      birthDate: '04.04.2011',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/7A-204',
      certifiedAt: '2026-11-02T14:40:22.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-7a-5',
      classId: 'cls-7a',
      fullName: 'Shermatov Eldorbek G\'ulom o\'g\'li',
      passport: 'AB8811225',
      birthDate: '28.08.2011',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-7a-6',
      classId: 'cls-7a',
      fullName: 'Zokirova Muslima Rustam qizi',
      passport: 'AC9922336',
      birthDate: '13.12.2011',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/7A-206',
      certifiedAt: '2026-11-03T10:00:00.000Z',
      paidAmount: 10000,
    },

    // 8-V students
    {
      id: 'std-8v-1',
      classId: 'cls-8v',
      fullName: 'Alimov Jahongir Baxtiyorovich',
      passport: 'FA1234567',
      birthDate: '10.01.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-301',
      certifiedAt: '2026-11-01T09:20:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-2',
      classId: 'cls-8v',
      fullName: 'Botirova Shabnam Farhod qizi',
      passport: 'FB2345678',
      birthDate: '18.05.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-302',
      certifiedAt: '2026-11-01T09:35:12.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-3',
      classId: 'cls-8v',
      fullName: 'Davlatov Samandar Botir o\'g\'li',
      passport: 'FC3456789',
      birthDate: '29.09.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-303',
      certifiedAt: '2026-11-01T10:00:45.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-4',
      classId: 'cls-8v',
      fullName: 'Hamdamova Charos Shuhrat qizi',
      passport: 'FA4567890',
      birthDate: '02.03.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-304',
      certifiedAt: '2026-11-01T10:25:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-5',
      classId: 'cls-8v',
      fullName: 'Inoyatov Miraziz Akmalovich',
      passport: 'FB5678901',
      birthDate: '14.07.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-305',
      certifiedAt: '2026-11-01T11:10:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-6',
      classId: 'cls-8v',
      fullName: 'Lapasov Shaxzodbek Ilhom o\'g\'li',
      passport: 'FC6789012',
      birthDate: '23.11.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-306',
      certifiedAt: '2026-11-01T11:45:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-7',
      classId: 'cls-8v',
      fullName: 'Murodova Gulnoza Valijon qizi',
      passport: 'FA7890123',
      birthDate: '06.02.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-307',
      certifiedAt: '2026-11-01T12:00:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-8',
      classId: 'cls-8v',
      fullName: 'Norboyev Jasurbek Jamoliddin o\'g\'li',
      passport: 'FB8901234',
      birthDate: '19.08.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-308',
      certifiedAt: '2026-11-01T12:30:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-9',
      classId: 'cls-8v',
      fullName: 'Ortiqov Bunyodbek Qobilovich',
      passport: 'FC9012345',
      birthDate: '31.10.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-309',
      certifiedAt: '2026-11-01T13:00:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-8v-10',
      classId: 'cls-8v',
      fullName: 'Shokirova Diyora Sardor qizi',
      passport: 'FA0123456',
      birthDate: '15.04.2010',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/8V-310',
      certifiedAt: '2026-11-01T13:20:00.000Z',
      paidAmount: 10000,
    },

    // 9-D students
    {
      id: 'std-9d-1',
      classId: 'cls-9d',
      fullName: 'Ashurov Asadbek Dilmurodovich',
      passport: 'FA1122334',
      birthDate: '04.03.2009',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/9D-401',
      certifiedAt: '2026-10-28T10:00:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-9d-2',
      classId: 'cls-9d',
      fullName: 'Choriyeva Feruza Hamidovna',
      passport: 'FB2233445',
      birthDate: '17.07.2009',
      status: 'pending',
      paidAmount: 10000,
    },
    {
      id: 'std-9d-3',
      classId: 'cls-9d',
      fullName: 'Eshonqulov Boburxon Sherali o\'g\'li',
      passport: 'FC3344556',
      birthDate: '26.11.2009',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/9D-403',
      certifiedAt: '2026-10-28T11:15:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-9d-4',
      classId: 'cls-9d',
      fullName: 'G\'ofurova Shahrizoda Sanjar qizi',
      passport: 'FA4455667',
      birthDate: '09.01.2009',
      status: 'pending',
      paidAmount: 10000,
    },

    // 11-A students
    {
      id: 'std-11a-1',
      classId: 'cls-11a',
      fullName: 'Abdullayeva Laylo Shuhrat qizi',
      passport: 'FA9988112',
      birthDate: '12.05.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-501',
      certifiedAt: '2026-10-20T14:00:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-11a-2',
      classId: 'cls-11a',
      fullName: 'Boymurodov Shahzodbek Jamshid o\'g\'li',
      passport: 'FB8877223',
      birthDate: '28.09.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-502',
      certifiedAt: '2026-10-20T14:15:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-11a-3',
      classId: 'cls-11a',
      fullName: 'Ibrohimov Doniyorbek Alisherovich',
      passport: 'FC7766334',
      birthDate: '15.02.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-503',
      certifiedAt: '2026-10-20T14:30:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-11a-4',
      classId: 'cls-11a',
      fullName: 'Mirzayeva Nozima Zafar qizi',
      passport: 'FA6655445',
      birthDate: '03.08.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-504',
      certifiedAt: '2026-10-20T15:00:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-11a-5',
      classId: 'cls-11a',
      fullName: 'Qodirov Sardorbek Ravshan o\'g\'li',
      passport: 'FB5544336',
      birthDate: '20.12.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-505',
      certifiedAt: '2026-10-20T15:20:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-11a-6',
      classId: 'cls-11a',
      fullName: 'Saidov Akbarjon Dilshodovich',
      passport: 'FC4433227',
      birthDate: '11.04.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-506',
      certifiedAt: '2026-10-20T15:45:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-11a-7',
      classId: 'cls-11a',
      fullName: 'Toshpo\'latova Zarina Farrux qizi',
      passport: 'FA3322118',
      birthDate: '24.10.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-507',
      certifiedAt: '2026-10-20T16:00:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-11a-8',
      classId: 'cls-11a',
      fullName: 'Usmonov Jaloliddin Bobur o\'g\'li',
      passport: 'FB2211009',
      birthDate: '07.01.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-508',
      certifiedAt: '2026-10-20T16:15:00.000Z',
      paidAmount: 10000,
    },
    {
      id: 'std-11a-9',
      classId: 'cls-11a',
      fullName: 'Xoliqova Feruzaxon Ma\'ruf qizi',
      passport: 'FC1100990',
      birthDate: '19.06.2007',
      status: 'certified',
      certificateUrl: 'https://cert.maktab.uz/verify/11A-509',
      certifiedAt: '2026-10-20T16:30:00.000Z',
      paidAmount: 10000,
    },
  ];

  const teachers = [
    {
      id: 'tch-1',
      fullName: 'Qodirova Nilufar Rustamovna',
      subject: 'Matematika va Algebra',
      passport: 'AA1144992',
      birthDate: '14.05.1985',
      emailOrPhone: '+998 90 123 45 67',
      certificateUrl: 'https://cert.maktab.uz/verify/TCH-001',
      certifiedAt: '2026-09-15T08:30:00.000Z',
      status: 'certified',
      price: 10000,
      paidAmount: 10000,
      notes: 'Oliy toifali o\'qituvchi, Milliy sertifikat egasi',
    },
    {
      id: 'tch-2',
      fullName: 'Xalilov Bobur Shavkatovich',
      subject: 'Informatika va AT',
      passport: 'AB2255883',
      birthDate: '29.08.1990',
      emailOrPhone: '+998 91 234 56 78',
      certificateUrl: 'https://cert.maktab.uz/verify/TCH-002',
      certifiedAt: '2026-09-20T11:00:00.000Z',
      status: 'certified',
      price: 10000,
      paidAmount: 10000,
      notes: '1-toifali ustoz, robototexnika to\'garak rahbari',
    },
    {
      id: 'tch-3',
      fullName: 'Rahimova Dilnoza Alisherovna',
      subject: 'Ingliz tili (CEFR C1)',
      passport: 'AC3366774',
      birthDate: '18.11.1992',
      emailOrPhone: '+998 93 345 67 89',
      certificateUrl: 'https://cert.maktab.uz/verify/TCH-003',
      certifiedAt: '2026-10-05T14:20:00.000Z',
      status: 'certified',
      price: 10000,
      paidAmount: 10000,
      notes: 'IELTS 8.0, xalqaro trener',
    },
    {
      id: 'tch-4',
      fullName: 'Toirov Jasur Bahromovich',
      subject: 'Fizika va Astronomiya',
      passport: 'AA4477665',
      birthDate: '02.04.1983',
      emailOrPhone: '+998 94 456 78 90',
      status: 'pending',
      price: 10000,
      paidAmount: 10000,
      notes: 'Navbatdagi attestatsiya jarayonida',
    },
    {
      id: 'tch-5',
      fullName: 'Mirzayeva Shahnoza Akramovna',
      subject: 'Ona tili va Adabiyot',
      passport: 'AB5588556',
      birthDate: '12.01.1988',
      emailOrPhone: '+998 97 567 89 01',
      certificateUrl: 'https://cert.maktab.uz/verify/TCH-005',
      certifiedAt: '2026-10-12T09:40:00.000Z',
      status: 'certified',
      price: 10000,
      paidAmount: 10000,
      notes: 'Filologiya fanlari bo\'yicha falsafa doktori (PhD)',
    },
    {
      id: 'tch-6',
      fullName: 'Soliyev Farrux Odilovich',
      subject: 'Tarix va Huquq asoslari',
      passport: 'AC6699447',
      birthDate: '25.07.1986',
      emailOrPhone: '+998 99 678 90 12',
      status: 'pending',
      price: 10000,
      paidAmount: 0,
      notes: 'Sertifikat to\'lovi kutilmoqda',
    },
  ];

  return {
    classes,
    students,
    teachers,
    settings: {
      defaultCertificatePrice: 10000,
      schoolName: "Prezident Ta'lim Muassasalari va Umumta'lim Maktabi",
      lastUpdated: new Date().toISOString(),
    },
  };
}

function loadDatabase() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
      if (data && Array.isArray(data.classes) && Array.isArray(data.students)) {
        return data;
      }
    }
  } catch (err) {
    console.error('Error reading db file, restoring fallback:', err);
  }
  const initial = getInitialData();
  saveDatabase(initial, true);
  return initial;
}

function saveDatabase(data: any, forceEmpty: boolean = false) {
  try {
    // Zero-data-loss wipe protection check
    if (!forceEmpty && fs.existsSync(DB_FILE)) {
      try {
        const existing = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
        const existingCount = (existing.classes?.length || 0) + (existing.students?.length || 0);
        const incomingCount = (data.classes?.length || 0) + (data.students?.length || 0);
        if (existingCount > 0 && incomingCount === 0) {
          console.warn('Blocked wipe attempt: existing count is', existingCount, 'incoming is 0');
          throw new Error('ZERO_DATA_LOSS_PROTECTION: Bo\'sh baza bilan to\'liq bazani o\'chirish bloklandi!');
        }
      } catch (e: any) {
        if (e.message?.includes('ZERO_DATA_LOSS_PROTECTION')) {
          throw e;
        }
      }
    }

    data.settings = data.settings || {};
    data.settings.lastUpdated = new Date().toISOString();

    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tempFile, DB_FILE);

    // Save automatic backup snapshot (keeps last 5 snapshots)
    const backupName = `backup_${Date.now()}.json`;
    fs.copyFileSync(DB_FILE, path.join(BACKUPS_DIR, backupName));
    const backupFiles = fs.readdirSync(BACKUPS_DIR).filter(f => f.startsWith('backup_')).sort();
    if (backupFiles.length > 5) {
      for (const old of backupFiles.slice(0, backupFiles.length - 5)) {
        try { fs.unlinkSync(path.join(BACKUPS_DIR, old)); } catch {}
      }
    }

    return true;
  } catch (err) {
    console.error('Save database failed:', err);
    throw err;
  }
}

// REST API ROUTES
app.post('/api/admin/login', (req, res) => {
  const ip = getClientIp(req);
  const now = Date.now();
  const rateLimit = loginRateLimitMap.get(ip) || { attempts: 0, lockedUntil: 0 };

  // Check if locked
  if (rateLimit.lockedUntil > now) {
    const remainingSecs = Math.ceil((rateLimit.lockedUntil - now) / 1000);
    const remainingMins = Math.ceil(remainingSecs / 60);
    return res.status(429).json({
      error: `Xavfsizlik blokirovkasi! Juda ko'p xato urinishlar. Iltimos ${remainingMins} daqiqadan so'ng qayta urinib ko'ring.`,
      lockedUntil: rateLimit.lockedUntil,
      remainingMinutes: remainingMins,
    });
  }

  const { password } = req.body;
  if (!password || typeof password !== 'string') {
    return res.status(400).json({ error: 'Parol kiritilmadi' });
  }

  const hashedInput = crypto.createHmac('sha256', SECRET_KEY).update(password).digest('hex');

  // Secure constant-time comparison
  const isValid = crypto.timingSafeEqual(Buffer.from(hashedInput, 'utf8'), Buffer.from(ADMIN_PASSWORD_HASH, 'utf8'));

  if (!isValid) {
    rateLimit.attempts += 1;
    if (rateLimit.attempts >= 5) {
      rateLimit.lockedUntil = now + 15 * 60 * 1000; // 15 mins
      rateLimit.attempts = 0;
      loginRateLimitMap.set(ip, rateLimit);
      return res.status(429).json({
        error: '5 marta noto\'g\'ri parol kiritildi! Tizim 15 daqiqaga bloklandi.',
        lockedUntil: rateLimit.lockedUntil,
        remainingMinutes: 15,
      });
    }
    loginRateLimitMap.set(ip, rateLimit);
    return res.status(401).json({
      error: 'Noto\'g\'ri administrator paroli!',
      remainingAttempts: 5 - rateLimit.attempts,
    });
  }

  // Password correct: reset rate limiting and return 24h admin token
  loginRateLimitMap.delete(ip);
  const { token, expiresAt } = generateAdminToken();

  return res.json({
    success: true,
    token,
    expiresAt,
    message: 'Administrator sifatida muvaffaqiyatli kirdingiz',
  });
});

app.get('/api/admin/verify', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : undefined;
  const valid = verifyAdminToken(token);
  return res.json({ valid });
});

app.get('/api/data', (req, res) => {
  try {
    const data = loadDatabase();
    return res.json(data);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Baza o\'qishda xatolik' });
  }
});

app.post('/api/data', (req, res) => {
  try {
    const incomingData = req.body;
    if (!incomingData || typeof incomingData !== 'object') {
      return res.status(400).json({ error: 'Noto\'g\'ri ma\'lumot formati' });
    }
    const forceEmpty = Boolean(req.query.forceEmpty === 'true');
    saveDatabase(incomingData, forceEmpty);
    return res.json({ success: true, lastUpdated: incomingData.settings?.lastUpdated });
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Saqlashda xatolik' });
  }
});

app.get('/api/backup/export', (req, res) => {
  try {
    const data = loadDatabase();
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="maktab_baza_backup_${new Date().toISOString().slice(0, 10)}.json"`);
    return res.send(JSON.stringify(data, null, 2));
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.post('/api/backup/restore', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : undefined;
  if (!verifyAdminToken(token)) {
    return res.status(403).json({ error: 'Zaxira nusxani tiklash uchun administrator huquqi talab etiladi!' });
  }

  try {
    const backupData = req.body;
    if (!backupData || !Array.isArray(backupData.classes) || !Array.isArray(backupData.students)) {
      return res.status(400).json({ error: 'Noto\'g\'ri backup fayl formati!' });
    }
    saveDatabase(backupData, true);
    return res.json({ success: true, message: 'Baza zaxira nusxadan muvaffaqiyatli qayta tiklandi!' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: 3000,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Maktab Ta'lim Portali CRM server running on port ${PORT} [${isProduction ? 'PRODUCTION' : 'DEVELOPMENT'}]`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
